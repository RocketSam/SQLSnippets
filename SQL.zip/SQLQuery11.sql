select	*
from		EDS_SUMMARY_RPT
where		ExaminationId = 624

select	*
from		ALL_INSTITUTIONS_RPT
where		[NAME] like '%FINKL%'


select	distinct ReasonCode, ReasonDesc
from		vw_FollowupReasons
where		ReasonDesc like '%Preda%'


select	e.DOCKET, *
from		dbo.vw_Followups fu
inner join	dbo.EDS_SUMMARY_RPT e
	on	fu.PrimaryKey = e.ExaminationId
where		fu.ReasonTypeCode = 'MRA'
	and	fu.ReasonCode = 'VM'
order by	ReasonCode


where		FollowUpId = 572


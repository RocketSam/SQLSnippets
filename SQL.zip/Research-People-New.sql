/*
	Research People @ CFPB
*/	

--	declare local variables
declare	@intPersonId		integer,
		@vcNameLast		varchar(50),
		@vcNameFirst	varchar(50)
		
select	@intPersonId = 9045
select	@vcNameFirst = ''
select	@vcNameLast = ''

--	find person
select	@intPersonId = PersonId
from		Core.dbo.Persons
where	(	LastName = @vcNameLast
	and	FirstName = @vcNameFirst
	)
	or	PersonId = @intPersonId
	
	
select	'Core.Persons' as TheSource, *
from		Core.dbo.Persons
where		PersonId = @intPersonId

select	'Core.Person and Core.Organizations' as TheSource, *
from		Core.dbo.Persons p
inner join	Core.dbo.Organizations o
	on	o.OrganizationID = p.OrganizationId
where		p.PersonId = @intPersonId

select	'SQLORD.VW_PersonDetail' as TheSource, *
from		SQLORD.dbo.VW_PersonDetail
where		PersonId = @intPersonId




-- END OF CODE
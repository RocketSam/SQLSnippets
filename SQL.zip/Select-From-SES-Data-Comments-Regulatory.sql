SELECT top 100
 '' as Docket
, '' as ExaminationId
, '' as RESTITUTION__C
,  vc.CommentId
, vc.Comment 
,'Other' as COMMENT_TYPE__C
, 'ViolationId' + cast(vc.ViolationId as varchar(10)) + '_' + cast((vv.ExaminationId) as varchar(10)) + '_' + cast(vv.CitationId as varchar(10)) as ViolationId
, vc.CreatedBy
, vc.CreatedDate
, vc.ModifiedBy
, vc.ModifiedDate
,'Violation' as ObjectType
FROM Regulatory.dbo.ViolationComments vc
inner join SQLORD.dbo.VW_Violations vv on vc.ViolationId=vv.ViolationId
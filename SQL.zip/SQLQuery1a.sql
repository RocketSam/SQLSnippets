/*		Research Activity Update
		
		use SQLORD
		select	*
		from		INFORMATION_SCHEMA.COLUMNS
		where		TABLE_NAME = 'ParDetail'
			and	DATA_TYPE = 'int'


*/
declare	@intPersonId	integer

select	@intPersonId = 12387

select	*
from		SQLORD.dbo.ParDetail
where		UserId = @intPersonId
	--and	Docket in ('00450','00105')
	and	Pay_Period_Date = '2017-01-08'
order by	Pay_Period_Date

SELECT
  DetailKey
, UserId
, Activity_Code
, Activity_Code_Desc
, Pay_Period_Date
, CASE Work_Location_Code WHEN 'I' THEN 'Institution' WHEN 'O' THEN 'Other' WHEN 'T' THEN 'Duty Station' END as Work_Location_Code
, Work_Location_Desc
, 	CASE Region_Emp
		WHEN 0
			THEN 'HQ'
		WHEN 1
			THEN 'Northeast'
		WHEN 2
			THEN 'Southeast'
		WHEN 3
			THEN 'Midwest'
		WHEN 4
			THEN 'West'
		END AS Region_Emp
, Job_Code
, Job_Code_Desc
, ExaminationId
, Docket
, Detail_Hours
--Codes for Detail_Type are normally: D= Docket, A= Administrative, E = Examination. We are changing it to match our TYPE__C
, CASE Detail_Type WHEN 'E' Then 'Examination' WHEN 'D' Then 'Non-Exam: Supervisory' WHEN 'A' Then 'Non-Exam: Administrative' END as Detail_Type
, Region_Docket
, CASE TrainingRole_Code WHEN 'R' THEN 'Trainer' WHEN 'E' THEN 'Trainee' END as TrainingRole_Code
, TrainingRole_Desc
, CASE LeadOffice_Code WHEN 'S' THEN 'Supervision' WHEN 'F' THEN 'Fair Lending' WHEN 'E' THEN 'Enforcement' END as LoadOffice_Code
, LeadOffice_Desc
, CASE Detail_Type When 'E' Then 'Exam' When 'D' Then 'Non-Exam Supervisory' Else 'Administrative' END as RECORDTYPENAME
FROM SQLORD.dbo.PARDetail
WHERE UserId = 12387
order by TrainingRole_Desc desc


/*
select	*
from		dbo.ParDetail
where		DetailKey = 101209
*/





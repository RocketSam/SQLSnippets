select	Name
		, ShortName
		, TaxId
		, is_rssd
		, id_cfpb
		, docket_id
		, *
from		CSM.dbo.ServiceProvidersMaster_CFPB
where		docket_id in ('00011','00017','00043','00051','00054')
order by	docket_id

select	*
from		CSM.dbo.ServiceProviders
where		Docket = '00011'


select	ShortName
		, TaxId
		, RSSDId
		, DOCKET
from		SQLORD.dbo.ALL_INSTITUTIONS_RPT
where		DOCKET = '00011'
		

/*
SELECT top 1000 ServiceProvidersMaster_CFPB_ID
      ,M.Name
      ,M.docket_id
      ,M.ActiveDate
      ,M.EntityTypeCode
      ,M.is_rssd
      ,M.docket_created
      ,M.TaxId
      , LEN(M.TaxId)    
FROM	CSM.dbo.ServiceProvidersMaster_CFPB M
--WHERE	M.TaxId like '71011870%'

INNER JOIN CSM.dbo.Regions R ON R.RegionId = M.LeadRegionId
WHERE M.docket_id IS NULL AND M.InactiveDate IS NULL 
            AND M.LeadRegionId IN (1) 
                  AND M.Name LIKE '%bank%'
*/

select	*
from		CSM.dbo.ServiceProvidersMaster_CFPB
where		docket_id in ('00011','00017','00043','00051','00054')
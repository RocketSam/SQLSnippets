select	eds.ExaminationId
	,	eds.DOCKET
	,	eds.REGION_ABV
from		SQLORD.dbo.EDS_SUMMARY_RPT eds
inner join	Core.dbo.OrganizationDockets od
	on	eds.DOCKET = od.Docket
inner join	Core.dbo.Organizations o
	on	o.OrganizationId = od.OrganizationId
inner join	Core.dbo.DocketStatuses ds
	on	od.DocketStatusCode = ds.DocketStatusCode	
where	(	(	eds.EXAM_TYPE in (10,12,16,17,20,21)
		and	eds.MAIL_DATE is not null
		and	eds.MAIL_DATE < '2015-02-15'
		)
	  or	(	eds.EXAM_TYPE in (11,15,30)
		)
	  or	(	eds.EXAM_TYPE in (31)
		and	eds.DraftToPRDate is not null
		and	eds.DraftToPRDate < '2015-02-15'
		)
	)
	and	ds.DocketStatusCode = 'A'

--SELECT	DISTINCT c.ShortDescript  -- From Miklane
SELECT	d.DocumentId,
		d.DocCategoryCodeId,
		d.[FileName],
		d.FileExtension,
		d.FileSize,
		d.ClientFilePath
FROM		[Regulatory].[dbo].[DocumentsRes]r
	JOIN	[Regulatory].[dbo].[Documents]d
	ON	r.DocumentId = d.DocumentId
	AND	d.deleted <> 1
	JOIN	[Regulatory].[dbo].[Examination]e
	ON	r.RelatedId = e.ExaminationId
LEFT JOIN	 [Regulatory].[dbo].[codes]c
	ON	d.DocCategoryCodeId = c.CodeId
	JOIN	[Regulatory].dbo.vw_institutions i
	ON	i.docket = e.docket
WHERE		d.ApplicationSystemId = 33 --33 = Examination
	AND	e.DeletedDate is NULL -- Excluded deleted exams
	AND	d.Unzip = 0 -- Exclude zip files uploaded and unzipped
	--AND	e.ExaminationId < 1235
ORDER BY	c.ShortDescript

-- Actual Error Query on Error Log -- NOT SURE WHY THIS IS EXECUTED
SELECT DISTINCT c.ShortDescript
FROM [Regulatory].[dbo].[DocumentsRes]r
JOIN [Regulatory].[dbo].[Documents]d
ON r.DocumentId = d.DocumentId
AND d.deleted <> 1
JOIN [Regulatory].[dbo].[Examination]e
ON r.RelatedId = e.ExaminationId
left outer join [Regulatory].[dbo].[codes]c
ON d.DocCategoryCodeId = c.CodeId
JOIN [Regulatory].dbo.vw_institutions i
ON i.docket = e.docket
WHERE d.ApplicationSystemId = 33 --33 = Examination
AND e.DeletedDate is NULL -- Excluded deleted exams
AND d.Unzip = 0 -- Exclude zip files uploaded and unzipped
ORDER BY c.ShortDescript

-- 2nd query --
SELECT --r.DocumentResId,r.DocumentId,
r.RelatedId as 'ExaminationId' --RelatedId is the Examinationid
,d.Document--,CONVERT(VARCHAR(MAX),d.Document) AS Document --This is the actual document
--,CORE.[dco].[UrlDecode](d.description) as UserComment
,d.FileName
--,d.FileExtension,d.FileSize,d.Deleted -- 1 = Deleted,d.isSecure -- 1 = Is Secure
,CASE
WHEN c.ShortDescript is NULL THEN 'Unassigned'
ELSE c.ShortDescript
END
AS 'CategoryShortDescription'
/*,CASE
WHEN c.Description is NULL THEN 'Unassigned'
ELSE c.Description
END
AS 'CategoryDescription',d.CreatedBy,d.CreatedDate,d.ModifiedBy,d.ModifiedDate
,CASE
WHEN i.supervisoryregion = 1 THEN 'NE'
WHEN i.supervisoryregion = 2 THEN 'SE'
WHEN i.supervisoryregion = 3 THEN 'MW'
WHEN i.supervisoryregion = 4 THEN 'WE'
END AS 'region'
*/
,i.supervisoryregion AS 'region'
FROM [Regulatory].[dbo].[DocumentsRes]r
Join [Regulatory].[dbo].[Documents]d
on r.DocumentId = d.DocumentId
and d.deleted &lt;&gt; 1
Join [Regulatory].[dbo].[Examination]e
on r.RelatedId = e.ExaminationId
left outer join [Regulatory].[dbo].[codes]c
on d.DocCategoryCodeId = c.CodeId
JOIN [Regulatory].dbo.vw_institutions i
ON i.docket = e.docket
Where d.ApplicationSystemId = 33 --33 = Examination
and e.DeletedDate is NULL -- Excluded deleted exams
and d.Unzip = 0 -- Exclude zip files uploaded and unzipped
/*
AND c.ShortDescript = 'Draft MOU, BR, ENF Act'
AND c.ShortDescript = 'Other Agency Exam Report'
AND c.ShortDescript = 'Other Agy Resp to CFPB Exam'
AND c.ShortDescript IS NULL
AND c.ShortDescript = 'Draft Exam Report'
AND c.ShortDescript = 'CFPB Trans Letter to Other Agy'
AND c.ShortDescript = 'CFPB Final Exam Report'
AND c.ShortDescript = 'MOU, BR, ENF Act'
AND c.ShortDescript = 'CFPB Resp to Other Agy Exam'*/
AND c.ShortDescript = 'CFPB Final Exam Report'
AND i.supervisoryregion = 1
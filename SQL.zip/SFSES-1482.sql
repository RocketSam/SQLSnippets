select	*
from		VW_LoadViewAllInstitutionsRptIT
where		Entity_Status = 'A'


select	vlv.Docket
		, vlv.Entity_Status
from		dbo.VW_LoadViewAllInstitutionsRptIT vlv
left join	dbo.ALL_INSTITUTIONS_RPT air
	on	vlv.Docket = air.DOCKET
where		air.DOCKET is null
order by	vlv.Docket

select	v.Docket
		, v.Entity_Status as VW_ENTITY_STATUS
		--, v.Entity_Status_Desc
		, v.[Name]
		, a.ENTITY_STATUS as ALL_ENTITY_STATUS
from		SQLORD.dbo.VW_LoadViewAllInstitutionsRptIT v
left join	SQLORD.dbo.ALL_INSTITUTIONS_RPT a
	on	v.Docket = a.DOCKET
	and	v.Entity_Status = 'V'
where		a.ENTITY_STATUS = 'A'
order by	v.Docket

select	v.Docket
		, v.Entity_Status as VW_ENTITY_STATUS
		--, v.Entity_Status_Desc
		, v.[Name]
		, a.ENTITY_STATUS as ALL_ENTITY_STATUS
from		SQLORD.dbo.VW_LoadViewAllInstitutionsRptIT v
left join	SQLORD.dbo.ALL_INSTITUTIONS_RPT a
	on	v.Docket = a.DOCKET
where		v.Entity_Status <> a.ENTITY_STATUS
order by	v.Docket
	

	

VW_LoadViewAllInstitutionsRptIT
VW_Structure
vw_TrustOnlyInstitutions



select	*
from		VW_LoadViewAllInstitutionsRptIT
where		DOCKET = '00246'


where		ENTITY_STATUS = 'A'
	and	COUNTRY_CODE not in ('01104')
	
select	*
from		dbo.ALL_INSTITUTIONS_RPT
where		COUNTRY_CODE = '01104'

select	*
from		Core.dbo.Organizations


	

select	LeadRegulatorCode,	
		COUNT(DOCKET) as Count_By_Lead_Regulator
from		dbo.ALL_INSTITUTIONS_RPT
where		ENTITY_STATUS = 'A'
group by	LeadRegulatorCode
with rollup

select	*
from		ALL_INSTITUTIONS_RPT
where		Docket = '00019'




select	ENTITY_STATUS,
		COUNT(DOCKET) as Count_By_Status
from		dbo.ALL_INSTITUTIONS_RPT
group by	ENTITY_STATUS
		

select	Entity_Type_Desc,
		COUNT(DOCKET) as Count_By_Entity_Type
from		dbo.ALL_INSTITUTIONS_RPT
where		ENTITY_STATUS = 'A'
group by	Entity_Type_Desc
with rollup




select	distinct Entity_Type_Desc
from		dbo.ALL_INSTITUTIONS_RPT

select	COUNT(*) 
from		dbo.ALL_INSTITUTIONS_RPT

select	DOCKET
		, [NAME]
		, ENTITY_STATUS
from		dbo.ALL_INSTITUTIONS_RPT
where		DOCKET = '00246'


select	o.Docket
		, o.OrganizationStatusCode as O_STATUS
		, a.[Name]
		, a.ENTITY_STATUS as ALL_STATUS
from		CSM.dbo.Organizations o
left join	SQLORD.dbo.ALL_INSTITUTIONS_RPT a
	on	o.Docket = a.DOCKET
	and	o.OrganizationStatusCode = 'V'
where		a.ENTITY_STATUS = 'V'
order by	o.Docket

select	v.Docket
		, v.Entity_Status as VW_ENTITY_STATUS
		--, v.Entity_Status_Desc
		, v.[Name]
		, a.ENTITY_STATUS as ALL_ENTITY_STATUS
from		SQLORD.dbo.VW_LoadViewAllInstitutionsRptIT v
left join	SQLORD.dbo.ALL_INSTITUTIONS_RPT a
	on	v.Docket = a.DOCKET
where		a.ENTITY_STATUS <> v.Entity_Status
order by	v.Docket

select	count(distinct Docket) as CountDocket
from		SQLORD.dbo.ALL_INSTITUTIONS_RPT
where		Entity_Status = 'A'


select	o.Docket
		, o.OrganizationStatusCode as O_STATUS
		, a.[Name]
		, a.ENTITY_STATUS as ALL_STATUS
from		CSM.dbo.Organizations o
inner join	SQLORD.dbo.ALL_INSTITUTIONS_RPT a
	on	o.Docket = a.DOCKET
	and	o.OrganizationStatusCode <> a.ENTITY_STATUS
order by	ALL_STATUS

select	*
from		CSM.dbo.Organizations
where		ModifiedBy = 11350
	and	ModifiedDate > '2017-01-01'
	
select	*
from		SQLORD.dbo.ALL_INSTITUTIONS_RPT
where		Docket = '00099'



select	*
from		Core.dbo.Persons
where		PersonId = 11350


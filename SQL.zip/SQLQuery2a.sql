-- only "Non-Government - Mastered"
select	*
from		SQLORD.dbo.ALL_INSTITUTIONS_RPT
where		[NAME] like 'Federal Reserve%'

-- "Government - Mastered"
select	'Core.dbo.Organizations' as TheSource, *
from		Core.dbo.Organizations
where		[Name] like 'Federal Reserve%'

select	'CSM.dbo.LeadRegulators' as TheSource, *
from		CSM.dbo.LeadRegulators
where		[Description] like 'Federal Reserve%'


select	*
from		CSM.dbo.ServiceProviders
where		[Name] like 'Federal Reserve%'

select	'Regulatory.dbo.ParticipatingAgencyList' as TheSource, *
from		Regulatory.dbo.ParticipatingAgencyList
where		OrganizationId = 14760


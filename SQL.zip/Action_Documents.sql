/*		ACTION DOCUMENTS and CASE DOCUMENTS
*/

/*SELECT	cast(d.DocumentId as varchar(9)) + '-DOC' as  DocumentId
	,	d.DocCategoryCodeId
	,	d.ApplicationSystemId
	,	d.FileName
	,	d.FileExtension
	,	d.FileSize
	,	d.ContentType
	,	d.Description
	,	d.ClientFilePath
	,	d.Indexed
	,	d.Deleted
	,	d.LastIndexedDate
	,	d.Unzip
	,	d.IsSecure
	,	d.CreatedBy
	,	d.CreatedDate
	,	d.ModifiedBy
	,	d.ModifiedDate
	,	c.Code
	,	c.ShortDescript
	,	c.Description as DOCUMENT_TYPE__C
	,	CASE  when CharIndex('draft',lower(c.ShortDescript))>0 Then 'Draft' when c.ShortDescript is null then null else 'Final' End as Status 
	,	dr.RelatedId
--    Removed RAD to support lookups against Mapping. 
--    , Case When d.ApplicationSystemId=52 then 'RAD'+ cast(dr.RelatedId as char(5)) else Null END As ACTION__C
	,	Case When d.ApplicationSystemId=52 then cast(dr.RelatedId as char(5)) else Null END As ACTION__C
	,	Case WHEN d.ApplicationSystemId=33 then cast(dr.RelatedId as char(5)) else Null END as CASE__C
	,	'Exam Reports/Letters' as RECORDTYPENAME
	,	'Regulatory.dbo.Documents' as SOURCE
*/	
SELECT	d.FileName
	,	dr.RelatedId	
	,	dr.*
FROM		Regulatory.dbo.Documents d 
LEFT JOIN	Regulatory.dbo.Codes c ON d.DocCategoryCodeId=c.CodeId
LEFT JOIN	Regulatory.dbo.DocumentsRes dr ON d.DocumentId=dr.DocumentId
WHERE		Deleted=0
	AND	d.ApplicationSystemId = 52
	AND	CHARINDEX(CHAR(37),FileName,1) > 0	
	
	
SELECT	d.FileName
	,	dr.RelatedId	
FROM		Regulatory.dbo.Documents d 
LEFT JOIN	Regulatory.dbo.Codes c ON d.DocCategoryCodeId=c.CodeId
LEFT JOIN	Regulatory.dbo.DocumentsRes dr ON d.DocumentId=dr.DocumentId
WHERE		Deleted=0	
	AND	d.FileName like 'F_00247_UMB_EID2131_31_Response%'
	
	

	


	
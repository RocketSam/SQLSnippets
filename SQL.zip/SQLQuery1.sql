select	top 10 e.*
from		Regulatory.dbo.Examination e
left join	SQLORD.dbo.EDS_SUMMARY_RPT esr
	on	e.ExaminationId = esr.ExaminationId
	and	e.DeletedDate is null  --<-- this means the Exam is still in the SES1 system
where		esr.ExaminationId is null --<-- this shows which e records are missing from esr
	and	esr.Entity_Status = 'I'
	

select	top 10 *
from		SQLORD.dbo.ALL_INSTITUTIONS_RPT
where		docket = '00011'


select	top 10 *
from		SQLORD.dbo.EDS_SUMMARY_RPT


select	top 10 *
from		SQLORD.dbo.FINANCIAL_DATA_RPT
where		Docket = '00011'

select	top 10 *
from		SQLORD.dbo.CASELOAD_DKTS_RPT
where		Docket = '00011'

select	*
from		dbo.ServiceProvidersMaster_CFPB
where		docket_id = '00011'





SELECT DISTINCT rad.radid,
                rad.docket,
                rad.actioncode,
                rad.actiondescription,
                rad.actionstatus,
                rad.formal_informal,
                rad.origregion,
                rad.initiateddate,
                rad.effectivedate,
                rad.closedate,
                rad.closecode,
                rad.closedscription,
                rad.actionagainstother,
                rad.ordernumber,
                rad.raddocuments,
                rad.radcomments,
                vrc.comment,
                rad.sumamountassessed,
                rad.sumamountcollected,
                rad.sumuncollectable,
                rad.sumamountoutstanding,
                rad.ispublicrelease,
                rad.ischiefcounsel,
                rad.isrestitutionapplicable,
                rad.createdby,
                rad.createddate,
                rad.modifiedby,
                rad.modifieddate,
                rad.notifyinstiadduedate,
                rad.notifyfdic_fincen_ofacdate,
                rad.entityresponse,
                rad.cfpbfollowup,
                rad.entity2ndresponse,
                rre.examinationid,
                rre.docket,
                rre.startdate,
                rre.examtype,
                rre.examtypedesc,
                ra.againstid,
                ra.amountassessed,
                ra.amountcollected,
                ra.uncollectable,
                ra.amountoutstanding,
                ra.againstname,
                ra.personsortingname,
                ra.againsttypecode,
                ra.againsttype,
                ra.estimatedassessment,
                ra.harmedconsumers,
                ra.extauditor,
                ra.restitutionstatus,
                'FollowUpId'
                + Cast(vfu.followupid AS VARCHAR(10)) + '_'
                + Cast(rad.radid AS VARCHAR(10)) + '_'
                + vfu.reasoncode                       AS REPORTABLE__C,
                'RAD' + Cast(rad.radid AS VARCHAR(10)) AS SES_PRIMARY_ACTION__C,
                'CFPB'                                 AS TYPE__C,
                'Restitution'                          AS RECORDTYPENAME
--, rad.RelatedDocket1
--, rad.RelatedDocket2
--, rad.NotifyIAPDate
--, rad.CFPB2ndFollowup
--, rad.ComplianceInd
--, rad.ComplianceDate
FROM   sqlord.dbo.radactiondetail rad
       LEFT JOIN sqlord.dbo.radrelatedexams rre
              ON rad.radid = rre.radid
                 AND rad.docket = rre.docket
       LEFT JOIN sqlord.dbo.radagainst ra
              ON rad.radid = ra.radid
       LEFT JOIN (SELECT *
                  FROM   sqlord.dbo.vw_followups
                  WHERE  primarykeytype = 'RADID') vfu
              ON rad.radid = vfu.primarykey --Issues here
       LEFT JOIN (SELECT *
                  FROM   sqlord.dbo.vw_radactionsflat) vrf
              ON rad.radid = vrf.radid --Actions here
       LEFT JOIN (SELECT relatedid,
                         comment
                  FROM   sqlord.dbo.vw_radcomments
                  WHERE  codeid = 656) vrc
              ON ra.againstid = vrc.relatedid
WHERE	rad.Docket = '00298'              
ORDER  BY 1,
          2  
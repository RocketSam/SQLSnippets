/*select	Code
		, [Description]
		, CodeTypeId
from		dbo.Codes
where	  (	Code in ('O','S','A','U','H','L','I','N')
	or	[Description] in ('Outstanding','Satisfactory','Above Average','Unsatisfactory','Needs to Improve','Substantial Noncompliance')
	  )
	and	CodeTypeId in (2,3,4,42,91)  
order by	[Description], Code
*/


select	eds.DOCKET
		, Comp_Rating_Co as 'Compliance Rating'
		, COMP_RATING_SS as 'Composite CRA Rating?'
		, CRA_RATING 
		, CRA_LENDING_TEST
		, CRA_INVESTMENT_TEST
		, CRA_SERVICE_TEST
		, v.*
from		SQLORD.dbo.EDS_SUMMARY_RPT eds
left join	Regulatory.dbo.Examination v
	on	v.DOCKET = eds.DOCKET
where	  (	CRA_RATING in ('O','S','A','U','H','L','I','N')
	   or	Comp_rating_Co in ('O','S','A','U','H','L','I','N')
	   or CRA_LENDING_TEST in ('O','S','A','U','H','L','I','N')
	   or CRA_SERVICE_TEST in ('O','S','A','U','H','L','I','N')
	   or COMP_RATING_SS in ('O','S','A','U','H','L','I','N')
	   )
	
	   
select	*
from		SQLORD.dbo.VW_LoadViewAllInstitutionsRptIT
where		DOCKET = '00246'
	   


		





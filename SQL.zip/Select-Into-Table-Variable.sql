/*		Using a Table Variable with IDENTITY
		Shows one example of @Table flexibility over #Temp tables
		Feb 23 2017
		C.Palamara
*/

declare	@intAction	integer

-- The beauty of doing this as a table variable is that you can set an automtically	
declare	@tblAgainst	table
	(	VarID integer primary key IDENTITY(1,1) NOT NULL
	,	TheDB varchar(50)
	,	TheTable varchar(50)
	,	RADId int
	,	AgainstId int
	)
		
		
select	@intAction = 35


insert into	@tblAgainst
	(	TheDB,
		TheTable,
		RADId,
		AgainstId
	)
select	'SQL Database'
	,	'The Table Name'
	,	RADId
	,	AgainstID
from		SQLORD.dbo.RADAgainst
where		RADId = @intAction

select	*
from		@tblAgainst


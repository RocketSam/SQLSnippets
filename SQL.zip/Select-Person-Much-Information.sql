/*

	Description:	SQL Code to retrieve as much information about a Person as possible.
	Date Created:	2017-Feb-14
	Created By:		Christine Palamara (Christine.Palamara@cfpb.gov)

--		Search for information in system tables
SELECT	TABLE_NAME, COLUMN_NAME
FROM		INFORMATION_SCHEMA.COLUMNS
WHERE		TABLE_NAME IN ('RADAGAINST')
ORDER BY	TABLE_NAME, ORDINAL_POSITION

Example:  Veronica Adams
Last Name:  Adams
First Name:  Veronica
PersonId:  13932
OrganizationId:  14763
PersonTypeCode:  R
UserName:  ADAMSV
UserNameId:  15422


Application System ID: 6
Application System: ECEF


Views with Errors:		dbo.VW_ApplicationRolePrivs
					dbo.vBBUserData
					
ECEF Permission:		dbo.VW_ApplicationSystems	
	Column:		ApplicationSystem
	Value:		ECEF
			

*/
--		Variable Declaration 
declare	@intPersonId		int
		, @intExaminationId	int	
		, @char5Docket		char(5)
		, @intUserNameId		int
		, @varUserName		varchar(32)
		, @intOrganizationId	int
		, @intApplicationSystemId int
		, @var75ApplicationSystemName varchar(75)

--		Variable Initialization		
select	@intPersonId = 13932,
		@intApplicationSystemId = 6,
		@intUserNameId = 15422


select	*
from		dbo.ApplicationSystems
where		ApplicationSystemId = @intApplicationSystemId

select	*
from		dbo.UserNamePrivs
where		UsernameId = @intUserNameId

/*		Free Development

select	ApplicationId
		, COUNT(*) as CountPerApp
from		dbo.VW_SecAuth
group by	ApplicationId

select	*
from		dbo.VW_SecAuth_All
where		PersonId = 13932
	or	UserNameId = 15422
	
select	*
from		dbo.VW_SecAuth
where		PrivilegeCode like '%ECEF%'

select	*
from		dbo.UserNamePrivsRestrStructure



	

*/
		





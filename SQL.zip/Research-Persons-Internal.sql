/*---	ALL ABOUT A PERSON -------------------------------------
	Description:  Statements to identify a Person in SES1
			  May be an Employee, Contractor, Case
			  Team Member
	Date:		  2017 March 15
	Author:	  Christine Palamara
	How to use:   Switch databases [line 16] to search for people using column names and values [lines 31,32].
	Possible data to use for searching:
	First Name
	Last Name
	Person ID
	User Name
	
*-------------------------------------------------------------*/		
-- Do Influential Parties and Employees --
use Core
declare	@vcSearch1		varchar(100)
	   ,	@vcSearch2		varchar(100)
	   ,	@vcValue1		varchar(100)
	   ,  @vcValue2		varchar(100)
	   ,	@intPersonId	integer
	   ,	@vcLastName		varchar(100)
	   ,	@vcFirstName	varchar(100)
	   ,	@vcUserName		varchar(100)

-- table variable to hold full database paths of all tables using PersonId		
declare	@tblFullDBPaths	table
	(	PathID int primary key IDENTITY(1,1) NOT NULL
		, FullDBPath varchar(100)
	)		
		
-- initialize variable(s)
select	@vcSearch1 = 'PersonId'
select	@vcValue1 = 14076

--select	@vcSearch2 = 'LastName'
--select	@vcValue2 = char(39) + 'UNASSIGNED' + char(39)

-- populate table variable
insert into	@tblFullDBPaths
	(	FullDBPath
	)
select	TABLE_CATALOG + '.' + TABLE_SCHEMA + '.' + TABLE_NAME
from		INFORMATION_SCHEMA.COLUMNS
where	  (	COLUMN_NAME = @vcSearch1
	   --or	COLUMN_NAME = @vcSearch2
	   )
group by	TABLE_CATALOG + '.' + TABLE_SCHEMA + '.' + TABLE_NAME

-- retrieve SQL statements
--select	'select * from ' + FullDBPath + ' where ' + @vcSearch + ' = ' + char(39) + @vcValue + char(39) + ';'
--from		@tblFullDBPaths

select	'select * from ' + FullDBPath + ' where ' + @vcSearch1 + ' = ' + @vcValue1 
--+  ' and ' + @vcSearch2 + ' = ' + @vcValue2 + ';'
from		@tblFullDBPaths


-- paste output here 
/*
select * from Core.dbo.Alias where LastName = 'Kidney'
select * from Core.dbo.PersonDeleteLog where LastName = 'Kidney'
select * from Core.dbo.Persons where LastName = 'Kidney'
select * from Core.dbo.VW_Contacts where LastName = 'Kidney'
select * from Core.dbo.VW_Contractors where LastName = 'Kidney'
select * from Core.dbo.VW_Employees where LastName = 'Kidney'
select * from Core.dbo.VW_EmployeesDetail where LastName = 'Kidney'
select * from Core.dbo.VW_PARVWALL_Users where LastName = 'Kidney'
select * from Core.dbo.VW_PersonAWSSchedules where LastName = 'Kidney'
select * from Core.dbo.VW_PersonDetail where LastName = 'Kidney'
select * from Core.dbo.VW_PersonDetail_salesforce where LastName = 'Kidney'
select * from Core.dbo.VW_Persons where LastName = 'Kidney'
select * from Core.dbo.VW_PersonUserName where LastName = 'Kidney'
select * from Core.dbo.VW_SecTrainingList where LastName = 'Kidney'
select * from Core.dbo.VW_UserNames where LastName = 'Kidney'



*/


/*	OUTPUT SECTION
Influential Parties are located:
	CSM.dbo.People (select * from CSM.dbo.People where LastName = 'Chadwell';)
	SQLORD.dbo.InfluentialParties (select * from SQLORD.dbo.InfluentialParties where LastName = 'Chadwell';)
	* * * they are not located in Core * * *
	
	
select	*
from		Core.dbo.VW_PersonDetail where LastName in ('Unassigned', 'System', 'Rearadmin', 'Nandan', 'Joshi', 'Adeyemo', 'Anderson')

	
*/
/*		Title: SQL-Documents-Analysis.sql
	     Author: Christine Palamara
	       Date: Mar 7 2017
	Description: Analysis of Document Extraction from SQL Server to a File Server	       






*/
--	Create Temp Table of Exams	
drop table #Exams
drop table #Documents	
select	eds.ExaminationId
	,	eds.DOCKET
	,	eds.REGION_ABV
into		#Exams	
from		SQLORD.dbo.EDS_SUMMARY_RPT eds
inner join	Core.dbo.OrganizationDockets od
	on	eds.DOCKET = od.Docket
inner join	Core.dbo.Organizations o
	on	o.OrganizationId = od.OrganizationId
inner join	Core.dbo.DocketStatuses ds
	on	od.DocketStatusCode = ds.DocketStatusCode	
/*
where	(	(	eds.EXAM_TYPE in (10,12,16,17,20,21)
		and	eds.MAIL_DATE is not null
		and	eds.MAIL_DATE < '2015-02-15'
		)
	  or	(	eds.EXAM_TYPE in (11,15,30)
		)
	  or	(	eds.EXAM_TYPE in (31)
		and	eds.DraftToPRDate is not null
		and	eds.DraftToPRDate < '2015-02-15'
		)
	)
*/
-- Now, documents.
select	d.DocumentId
		, d.[FileName]
		, d.CreatedDate
		, d.ModifiedDate
into		#Documents		
from		Regulatory.dbo.Documents d
where	(  (	d.CreatedBy < cast('2015-02-15' as datetime)
	  and	d.ModifiedDate is null
	   )
	   or 
	   (	d.ModifiedDate is not null
	  and	d.ModifiedDate < cast('2015-02-15' as datetime)  
	  )
	)  
--	Exams for Miklane   --	
/*
select	t.ExaminationId
		, t.DOCKET
		, t.REGION_ABV
		, o.[Name] as Organization_Name
		, o.[Status] as Organization_Status
		, ds.[Description] as DocketStatus_Description
from		Core.dbo.Organizations o
inner join	Core.dbo.OrganizationDockets od
	on	o.OrganizationId = od.OrganizationId
inner join	Core.dbo.DocketStatuses ds
	on	od.DocketStatusCode = ds.DocketStatusCode	
inner join	#Exam_Docket_Closed t	
	on	t.DOCKET = od.Docket
inner join	Regulatory.dbo.SupplExamDoc sed
	on	t.ExaminationId = sed.SupplExamId
	and	t.Docket = 	
where		o.[Status] = 1
	and	t.ExaminationId in
	(	select	sed.SupplExamId as [ExaminationId]
		from		Regulatory.dbo.SupplExamDoc sed
*/		

select	distinct edc.*
from		#Exam_Docket_Closed edc -- Exams with Docket Numbers where the Exam is closed
inner join	Regulatory.dbo.Workpapers w
	on	w.ExaminationId = edc.ExaminationId
inner join	#Documents_Old do
	on	w.WorkpaperId = do.DocumentId
order by	edc.ExaminationId	


inner join	Regulatory.dbo.SupplExamDoc sed
	on	sed.SupplExamId = edc.ExaminationId
inner join	#Documents_Old do
	on	sed.SupplExamDocId = do.DocumentId
		


/*	DEV AREA

select	top 100 *
from		Regulatory.dbo.Examination


select	EXAM_TYPE
		, COUNT(Distinct ExaminationId) as CountExamsPerType
from		EDS_SUMMARY_RPT
group by	EXAM_TYPE
order by	EXAM_TYPE
*/



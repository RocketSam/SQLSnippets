select	'Reg.Examination' as TheSource
		, ExaminationId
		, DeletedDate
		, DeletedSysDate
from		Regulatory.dbo.Examination
where		ExaminationId = 2070

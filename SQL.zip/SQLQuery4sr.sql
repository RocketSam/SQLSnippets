-- this one is good for selecting from Documents
select	r.RelatedId as ExaminationId,
		d.DocumentId,
		DATALENGTH(d.Document) as Document_Datalength_In_Bytes,
		d.FileSize,
		d.[FileName],
		d.DocCategoryCodeId
		--MAX(d.FileSize) as Max_File_Size_In_Kilobytes
		--MAX(DATALENGTH(d.Document)) as Max_Data_Length_In_Bytes
from		Regulatory.dbo.Documents d
inner join	Regulatory.dbo.DocumentsRes r
	on	d.DocumentId = r.DocumentId
where		r.RelatedId in
	(	select	ExaminationId
		from		Regulatory.dbo.Examination 
		where		Docket in
		(	select Docket
			from   Regulatory.dbo.VW_Institutions
			--where	 SupervisoryRegion in (1,2)
		)	
		and		DeletedDate is null
		--and		ExaminationId between 592 and 598
		--and		ExaminationId >= 419
	)	
	and	d.ApplicationSystemId = 33  --Examinations
	and	d.Unzip = 0
	--and	d.DocCategoryCodeId = 893 --'CFPB Final Exam Report'
	--and	d.FileSize > 65000  --greater than 64 MB (approx)
	and   DATALENGTH(d.Document) > 10000000
--ORDER BY	d.DocCategoryCodeId	
ORDER BY	Document_Datalength_In_Bytes desc	
--ORDER BY	r.RelatedId
/*
3 null
6 893
3 995
13 923
*/
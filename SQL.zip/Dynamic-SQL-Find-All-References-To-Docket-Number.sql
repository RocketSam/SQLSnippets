/*		Search SES1 Legacy Database for all references to a given Docket #
		2017-05-31	palamarac
*/
declare	@nvcSQL	nvarchar(1000)
declare	@vcTable	varchar(75)
declare	@Docket	char(5)
declare	@vcDatabase	varchar(75)

set		@Docket = '00560'  -- SVB Financial Group
set		@vcDatabase = 'Regulatory'
set		@vcTable = 'VW_RADAgainst'

set	@nvcSQL = 'SELECT * FROM ' + @vcDatabase + '.dbo.' + @vcTable + ' WHERE Docket = ' + @Docket
--+ ' WHERE RelatedId = ' + @Docket
--+ ' WHERE Docket = ' + @Docket

execute sp_executesql @nvcSQL	

/*
SQLORD
ALL_INSTITUTIONS_RPT
FINANCIAL_DATA_RPT
VW_RADActionsFlat
VW_Followups
ParDetail
InfluentialParties



Regulatory
Examination
PARHours
RADRelatedDockets

vw_LegacyEDS_DistinctExams
VW_Liabilities
VW_MRA_Data
VW_MRA_Summary
VW_MRA_SummaryData
vw_OrganizationDockets
vw_ParticipatingAgencies
vw_PCARatings
VW_RAD_MetaData
VW_RADActions
VW_RADAgainst
VW_RADDocket
VW_RADIPLs
VW_RADIPLsConcatenated
VW_RADReasons
VW_RADReasonsConcatenated
VW_Ratings
VW_ROE_MetaData
VW_ROEComplianceRatings
VW_ROEExamRatings
VW_ROEExamRatings_HC
vw_ROENames
VW_ScheduledActivities
VW_ScheduledActivitiesFromBkup
VW_ScheduledActivitiesFromCopy
VW_SESNextExamination
VW_SESNextInstitutions
VW_Structure
VW_TFRSC60
VW_TFRTrustAssets
vw_Trust
VW_Violations
VW_WorkPaper_MetaData

Core
OrganizationDockets
OrganizationNarrative
OrganizationNarrativeAudit
REG_NARRATIVE
REG_NARRATIVE_AUDIT
VW_CRAType
VW_DistinctDocketInstitutions
VW_HighProfile
VW_InstitutionBusinessTypes
VW_Institutions
VW_OrganizationShortNames

CSM
AnticipatedActivities
Conversion_EliminatedDockets
InstitutionAudit
OrganizationBusinessTypes
OrganizationDocuments
OrganizationFollowUp
OrganizationNetworks
OrganizationPeople
OrganizationPeopleComments
OrganizationPeopleContactTypes
OrganizationPeopleEmails
OrganizationPeoplePhoneNumbers
OrganizationPeopleTitles
OrganizationPlatforms
Organizations
OrganizationSupplementals
ServiceProviderComments
ServiceProviders
VW_CompareInstitutionData
VW_CSMCOREAddressDiffs
VW_ExamDates
VW_Institutions
VW_RADDocket

use CSM
select	TABLE_NAME
from		INFORMATION_SCHEMA.COLUMNS
where		COLUMN_NAME = 'Docket'
order by	TABLE_NAME
*/

	
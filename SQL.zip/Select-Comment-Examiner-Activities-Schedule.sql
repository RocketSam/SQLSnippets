declare	@intPersonId integer
set		@intPersonId = 10368

select	'ExaminerActivities (33)' as SourceRecord, *
from		dbo.ExaminerActivities
where		PersonId = @intPersonId

select	'ExamSchedule (13)' as SourceRecord, *
from		dbo.ExamSchedule
where		PersonId = @intPersonId

select	'VW_ScheduledEmployees (193)' as SourceRecord,*
from		dbo.VW_ScheduledEmployees
where		PersonId = @intPersonId

select	'VW_ExamSchedule (143)' as SourceRecord,*
from		dbo.VW_ExamSchedule
where		PersonId = @intPersonId

select	'VW_ExaminerActivities (50)' as SourceRecord,*
from		dbo.VW_ExaminerActivities
where		PersonId = @intPersonId

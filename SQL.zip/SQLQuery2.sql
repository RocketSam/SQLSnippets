SELECT '0000CFPB' AS Docket
	,PersonId
	,LastName
	,FirstName
	,MiddleName
	,''
	,NameSuffix
	,PersonTypeCode
	,PersonTypeDescription
	,JobDescription
	,WorkPhone
	,EmailAddress
	,'Associate'
	,HireDate
	,CASE RegionId
		WHEN 0
			THEN 'HQ'
		WHEN 1
			THEN 'Northeast'
		WHEN 2
			THEN 'Southeast'
		WHEN 3
			THEN 'Midwest'
		WHEN 4
			THEN 'West'
		END AS RegionId
	,LocationState
,CFPBId
FROM SQLORD.dbo.VW_PersonDetail_salesforce
WHERE PersonTypeCode NOT IN ('S')
and PersonId = 14862
/*		RESEARCH CASE DOCUMENTS
		WORKPAPERS and CASE DOCUMENTS are stored in different tables.
		

*/
-- WORKPAPERS
SELECT	cast(w.WorkpaperId as varchar(9)) + '-WP' as  WorkPaperId
	,	w.ExaminationId
	,	w.PartitionValueWP
	,	w.SupplExamDocId
	,	s.SupplExamDocDescription
	,	s.SupplExamDocName
	,	s.SupplExamDocOrderNum
	,	w.FileName
	,	w.FileExtension
	,	w.FileSize
	,	w.ContentType
	,	w.Description
	,	w.ClientFilePath
	,	w.Indexed
	,	w.Deleted
	,	w.LastIndexed
	,	w.Unzip
	,	w.ArchivedFilePath
	,	w.CreatedBy
	,	w.CreatedDate
	,	w.ModifiedBy
	,	w.ModifiedDate
	,	'Work Paper' as RECORDTYPENAME
	,	'Regulatory.dbo.Workpapers' as SOURCE
FROM		Regulatory.dbo.WorkPapers w
INNER JOIN	Regulatory.dbo.SupplExamDoc s
	ON	w.SupplExamDocId = s.SupplExamDocId
WHERE		w.Deleted=0
	AND	s.SupplExamDocName like '990%'
ORDER BY	w.ExaminationId	
	
	
-- REGULAR CASE DOCUMENTS
SELECT	d.FileName
	,	dr.RelatedId	
FROM		Regulatory.dbo.Documents d 
LEFT JOIN	Regulatory.dbo.Codes c ON d.DocCategoryCodeId=c.CodeId
LEFT JOIN	Regulatory.dbo.DocumentsRes dr ON d.DocumentId=dr.DocumentId
WHERE		Deleted=0	
	AND	d.FileName like '990%'
		
/*
--	ACCOUNT				
select	*
from		SQLORD.dbo.ALL_INSTITUTIONS_RPT
where		ADDRESS <> MailAddress


select	REGION,
		REGION_ABV,
		COUNT(*)
from		SQLORD.dbo.ALL_INSTITUTIONS_RPT
group by	REGION,
		REGION_ABV
		
--	MILESTONE__C			
select	top 1000 *
from		SQLORD.dbo.EDS_SUMMARY_RPT
order by	Docket

--	ASSIGNMENT_TRACKER	--
select	*
from		SQLORD.dbo.ParDetail


--	CASE					
select	*
from		SQLORD.dbo.EDS_SUMMARY_RPT
where		ExaminationId = 1655

select	EXAM_TYPE, ExaminationId
from		SQLORD.dbo.EDS_SUMMARY_RPT
where		GPRADeadline is not null

select	EXAM_TYPE, count(ExaminationId) as CountExamsByType
from		SQLORD.dbo.EDS_SUMMARY_RPT
where		GPRADeadline is not null
group by	EXAM_TYPE
order by	EXAM_TYPE
*/

--	REPORTABLE				
select	*
from		SQLORD.dbo.vw_Followups
where		ExaminationId in (602, 779, 611)


		
				
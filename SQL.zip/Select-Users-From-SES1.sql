SELECT * 
FROM   (SELECT username, 
               email, 
               grouplabel, 
               Row_number() 
                 OVER ( 
                   partition BY username 
                   ORDER BY username ) AS ROWNUMBER 
        FROM   [pSecureauthSQL].[dbo].[group_lookup] gl 
               LEFT JOIN [pSecureauthSQL].[dbo].[results] r 
                      ON gl.agrp_agrp_id = r.agrp_id 
               LEFT JOIN [pSecureauthSQL].[dbo].[usr_name_id] un 
                      ON Upper(gl.user_info_username) = Upper(un.username) 
        WHERE  r.grouplabel LIKE Lower('%ecef%')) AS a 
WHERE  a.rownumber = 1 
ORDER  BY username 

--inner level FROM--
SELECT	username, 
		email, 
            grouplabel, 
            Row_number() 
            OVER ( 
                   partition BY username 
                   ORDER BY username 
                   ) AS ROWNUMBER 
FROM		[pSecureauthSQL].[dbo].[group_lookup] gl 
LEFT JOIN	[pSecureauthSQL].[dbo].[results] r 
	ON	gl.agrp_agrp_id = r.agrp_id 
LEFT JOIN	[pSecureauthSQL].[dbo].[usr_name_id] un 
	ON	Upper(gl.user_info_username) = Upper(un.username) 
WHERE		r.grouplabel LIKE Lower('%ecef%')
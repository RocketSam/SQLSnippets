declare @charDocket char(5),
	  @intRADId integer
	  
select  @charDocket = '00214',
	  @intRADId = 38



select	'RadActionDetail' as The_Table, OrderNumber, *
from		dbo.RadActionDetail
where		Docket = @charDocket


select	'RadActionDetail FK in RADReasons' as The_Table
		,rr.RADId
		,rr.ReasonCode
		,rr.ReasonDescription
		,rad.*
from		dbo.RadActionDetail rad
left join	dbo.RADReasons rr
	on	rad.RADId = rr.RADId
	--and	rad.ActionCode = rr.ReasonCode
where		rad.Docket = @charDocket

select	'vw_Followups' as The_Table, *
from		dbo.vw_Followups
where		PrimaryKeyType = 'RADID'
--	and	PrimaryKey between 30 and 40
	
select	'RADAgainst' as The_Table,*
from		Regulatory.dbo.RADAgainst
where		RADId = @intRADId
	or	AgainstId = @intRADId

select	'RADMonetaryValues' as The_Table, *
from		Regulatory.dbo.VW_RADMonetaryValues
where	(	RADId = @intRADId	
	or	AgainstId = @intRADId
	)
	
select	*
from		Regulatory.dbo.VW_RadComments
where		RelatedId = @intRADId

select	FirstName
	,	MiddleName
	,	LastName
	,	PersonStatus
	,	Personid
	,	CFPBId
from		SQLORD.dbo.VW_PersonDetail_salesforce
where		PersonTypeCode = 'E'
	and	PersonStatus = 1
	and	CFPBId is null

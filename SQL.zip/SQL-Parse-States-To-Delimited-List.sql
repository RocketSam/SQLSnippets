--This code is from http://stackoverflow.com/questions/194852/concatenate-many-rows-into-a-single-text-string

select	distinct es2.ExaminationId, 
		substring(
		(
			select	';' + es1.State AS [text()]
			from		Regulatory.dbo.ExaminationStates es1
			where		es1.ExaminationId = es2.ExaminationID
			order by	es1.ExaminationId
			for XML PATH ('')
		), 2, 1000) [State]
From		Regulatory.dbo.ExaminationStates es2

--Or you can use this:
select	distinct es2.ExaminationId, 
		States = 
		STUFF((	-- add/remove + char(39) to add/remove single quotes, ASCII 39
				select	',' + es1.[State] AS [text()]
				from		Regulatory.dbo.ExaminationStates es1
				where		es1.ExaminationId = 425
				--es2.ExaminationID
				order by	es1.ExaminationId
				for XML PATH (''), TYPE
			).value('.', 'varchar(max)')--end of 1st argument in STUFF
			, 1, 1, '' ) -- character #1, for 1 character, replace with blank (STUFF ARGS 2,3)
From		Regulatory.dbo.ExaminationStates es2


select	',' + es1.State AS [text()]
from		Regulatory.dbo.ExaminationStates es1
where		es1.ExaminationId = 425
order by	es1.ExaminationId
for XML PATH (''), TYPE

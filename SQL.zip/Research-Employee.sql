/*		Research Activity Update
*/
/*		Most of the detail comes from SQLORD.dbo.PARDetail
		You cannot use DetailKey as any kind of key, despite the name.
		This table gets nuked and paved every night; therefore, the 
		DetailKey is different every day.
*/
/*
		select * from Core.dbo.VW_PersonDetail where FirstName = 'Peter'
*/
declare	@intPersonId	integer

select	@intPersonId = PersonId
from		Core.dbo.VW_PersonDetail
where		FirstName = 'Peter'
	and	LastName = 'Glesius'
	
select	@intPersonId = 9396	--Peter Glesius
--select	@intPersonId = 9526	--Hugh Locker
	
select	pd.UserId
	,	vpd.FirstName
	,	vpd.LastName
	,	pd.Activity_Code
	,	pd.Activity_Code_Desc
	,	pd.Pay_Period_Date
	,	pd.ExaminationId
	,	pd.Docket
	,	pd.Detail_Hours
	,	air.NAME as Institution_Name
	,	pd.Work_Location_Code
	,	pd.Detail_Type
	,	pd.*
from		SQLORD.dbo.PARDetail pd
left join	SQLORD.dbo.VW_PersonDetail vpd
	on	pd.UserId = vpd.PersonId
left join	SQLORD.dbo.ALL_INSTITUTIONS_RPT air
	on	pd.Docket = air.DOCKET
where		pd.UserId = @intPersonId
	and	pd.Detail_Type <> 'E'
	--and	pd.Activity_Code = 90000
	--and	pd.Pay_Period_Date = '2013-12-01'
	--and	pd.Docket = '00087'
	--and	pd.Docket is null
order by	pd.Pay_Period_Date

--=============================================================--
--		SUM of HOURS BY DOCKET for USER (non-exam)
--=============================================================--
select	pd.UserId
	,	vpd.FirstName
	,	vpd.LastName
	,	pd.Docket
	,	SUM(pd.Detail_Hours) SumHoursByDocket
from		SQLORD.dbo.PARDetail pd
inner join	SQLORD.dbo.VW_PersonDetail vpd
	on	pd.UserId = vpd.PersonId
left join	SQLORD.dbo.ALL_INSTITUTIONS_RPT air
	on	pd.Docket = air.DOCKET
where		pd.UserId = @intPersonId
	and	pd.Detail_Type <> 'E'
group by	pd.UserId
	,	vpd.FirstName
	,	vpd.LastName
	,	pd.Docket


--=============================================================--
--		SUM of HOURS BY DOCKET for USER (non-exam)
--=============================================================--
select	pd.UserId
	,	vpd.FirstName
	,	vpd.LastName
	,	pd.Docket
	,	SUM(pd.Detail_Hours) SumHoursByDocket
from		SQLORD.dbo.PARDetail pd
inner join	SQLORD.dbo.VW_PersonDetail vpd
	on	pd.UserId = vpd.PersonId
left join	SQLORD.dbo.ALL_INSTITUTIONS_RPT air
	on	pd.Docket = air.DOCKET
where		pd.UserId = @intPersonId
	and	pd.Detail_Type <> 'E'
group by	pd.UserId
	,	vpd.FirstName
	,	vpd.LastName
	,	pd.Docket
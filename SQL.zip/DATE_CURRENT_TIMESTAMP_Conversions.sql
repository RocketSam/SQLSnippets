select @@version



SELECT CAST(FLOOR(CAST(CURRENT_TIMESTAMP AS float)) AS DATETIME)

SELECT		     CURRENT_TIMESTAMP

SELECT		CAST(CURRENT_TIMESTAMP AS float)

SELECT	FLOOR(CAST(CURRENT_TIMESTAMP AS float))

SELECT	CONVERT(VARCHAR,CAST(CURRENT_TIMESTAMP AS DATETIME), 110)


SELECT	CAST(CURRENT_TIMESTAMP AS float)


declare @datetime datetime;
set @datetime = CURRENT_TIMESTAMP;
select @datetime;
select dateadd(year,datediff(year,0,@datetime),0) as TheYear;
select dateadd(month,datediff(month,0,@datetime),0) as TheMonth;
select dateadd(day,datediff(day,0,@datetime),0) as TheDay;
select dateadd(hour,datediff(hour,0,@datetime),0) as TheHour;
select dateadd(minute,datediff(minute,0,@datetime),0) as TheMinute;
select dateadd(second,datediff(second,'2000-01-01',@datetime),'2000-01-01') as TheSecond;

select	cast(cast(CURRENT_TIMESTAMP as date) as datetime)

SELECT	CAST(CAST(CURRENT_TIMESTAMP as DATE) as DATETIME, 110)




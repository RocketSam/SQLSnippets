SELECT CAST(o.OrganizationID AS VARCHAR(10))
	,[Name]
	,'Government - Mastered' AS RECORDTYPENAME
	,''
	,'' AS ADDRESS
	,'' AS ADDRESS2
	,'' AS CITY
	,'' AS "STATE"
	,'' AS ZIP
	,'' AS COUNTRY_CODE
	,'' AS COUNTRY
	,'' AS MailAddress
	,'' AS MailCity
	,'' AS MailState
	,'' AS MailZip
	,'' AS MailCountryCode
	,'' AS MailCountry
	,'' AS REGION
	,'' AS REGION_ABV
	,'' AS REGION_NAME
	,'' AS MonitoringProfiles
	,'' AS NAME
	,null AS MlsID
	,'' AS Phone
	,'' AS LeadRegulatorCode
	,null AS RSSDId
	,'' AS ShortName
	,'' AS ENTITY_STATUS
	,'' AS TaxId
	,'' AS ENTITY_TYPE
	,'' AS ENTITY_TYPE_DESC
	,'' AS WWW_ADDRESS
   , '' AS FAX
FROM [Core].[dbo].[Organizations] O
JOIN [Regulatory].[dbo].[ParticipatingAgencyList] P ON o.OrganizationID = p.organizationid
WHERE STATUS = 1
	AND NAME IN (
		'Federal Trade Commission'
		,'State'
		,'Federal Reserve Board'
		)
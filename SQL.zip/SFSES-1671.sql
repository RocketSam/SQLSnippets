/*		SFSES-1671  :: Issues in Migrated Restitution
		Feb 22 2017
*/

declare	@intAction	integer
	,	@chrDocket	char(5)
	
declare	@tblAgainst	table
	(	TheDB varchar(50)
	,	TheTable varchar(50)
	,	RADId int
	,	AgainstId int
	)
		
		
select	@intAction = 35

select	@chrDocket = Docket
from		SQLORD.dbo.RadActionDetail
where		RADId = @intAction

select	rad.RADId
	,	rad.Docket
	,	rad.ActionCode
	,	rad.ActionDescription
	,	rad.ActionStatus
	,	ra.AgainstId
	,	vrc.RelatedId
	,	vrc.Comment
from		SQLORD.dbo.RadActionDetail rad
inner join	SQLORD.dbo.RADAgainst ra
	on	rad.RADId = ra.RADId
inner join	SQLORD.dbo.VW_RADComments vrc
	on	ra.AgainstId = vrc.RelatedId
where		rad.RADId = @intAction
	and	rad.Docket = @chrDocket
	and	vrc.Code = 'RCOMMT'
		
		
select	'SQLORD' as TheDB
		, 'RADActionDetail' as TheTable
		, *
from		SQLORD.dbo.RADActionDetail
where		RADId = @intAction
	and	Docket = @chrDocket


insert into	@tblAgainst
	(	TheDB,
		TheTable,
		RADId,
		AgainstId
	)
select	'SQLORD'
	,	'RADAgainst'
	,	RADId
	,	AgainstID
from		SQLORD.dbo.RADAgainst
where		RADId = @intAction

select	*
from		@tblAgainst

select	'SQLORD' as TheDB
	,	'VW_RADComments' as TheTable
	,	*
from		SQLORD.dbo.VW_RADComments
where		RelatedID = 125
	




/*		T E S T I N G  ||  D E V E L O P M E N T   A R E A

select	*
from		SQLORD.dbo.VW_RADActionsFlat
where		RADId = 109

select	*
from		VW_RADComments
where		RelatedId = 109

	
*/					
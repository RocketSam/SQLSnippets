/*

	Troubleshooting ACTIONS for Erin on 7/22

*/

use SQLORD
go

declare	@vfFollowUpId varchar(25),
		@vfPrimaryKey varchar(25)
		
select	@vfFollowUpId = 498  --860
select	@vfPrimaryKey = 108		

select	*
from		SQLORD.dbo.vw_Followups
where		FollowUpID in (498,860)
	and	PrimaryKey = @vfPrimaryKey
	and	ReasonCode = 'BCMS'


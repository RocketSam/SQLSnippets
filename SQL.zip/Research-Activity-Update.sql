/*
	Research Activity Update Records for an Employee
*/	

--	declare local variables
declare	@intPersonId	integer,
		@vcNameFirst	varchar(50),
		@vcNameLast		varchar(50)
		
select	@intPersonId = 0
select	@vcNameFirst = 'Peter'
select	@vcNameLast = 'Glesius'

select	@intPersonId = PersonId
from		Core.dbo.Persons
where		LastName = @vcNameLast
	and	FirstName = @vcNameFirst
	

select	'Regulatory.PARData' as TheSource, *
from		Regulatory.dbo.PARData
where		PersonId = @intPersonId


select	'SQLORD.VW_ExamPARHoursExist' as TheSource, *
from		SQLORD.dbo.VW_ExamPARHoursExist
	
		
select	'Regulatory.PARHours' as TheSource, *
from		Regulatory.dbo.PARHours
where		CreatedBy = @intPersonId	

select	'SQLORD.PARDetail' as TheSource, *
from		SQLORD.dbo.PARDetail
where		UserId = @intPersonId
order by	Detail_Type, Activity_Code_Desc	

select	pd.UserId
		, p.FirstName
		, p.LastName
		, pd.ExaminationId
		, pd.Job_Code
		, pd.Job_Code_Desc
		, pd.Activity_Code
		, pd.Activity_Code_Desc
		, pd.Docket
from		Core.dbo.Persons p
inner join	SQLORD.dbo.PARDetail pd
	on	pd.UserId = p.PersonId
inner join	Regulatory.dbo.Examination e
	on	pd.ExaminationId = e.ExaminationId
where		e.DeletedDate is not null
	and	pd.UserId = @intPersonId
order by	pd.ExaminationId
		, p.PersonId
		

	
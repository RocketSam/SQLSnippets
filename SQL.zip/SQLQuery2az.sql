/*		Research Entity -- Institution -- Docket -- Account -- SES1 -- MED
*/
/*
id_cfpb	batch_id	source	source_id
1713048034	sourceingest-20	ses	00580
3977756698	sourceingest-20	ses	00590
3986823385	sourceingest-20	ses	00564
4015991285	sourceingest-20	ses	00579
4402915264	sourceingest-20	ses	00584
4429320895	sourceingest-20	ses	00572
4650663740	sourceingest-20	ses	00576
4731509263	sourceingest-20	ses	00617
4854718372	sourceingest-20	ses	00569
6102096371	sourceingest-20	ses	00575
7499532788	sourceingest-20	ses	00554
7790078634	sourceingest-20	ses	00564
8286976557	sourceingest-20	ses	00566
9290861276	sourceingest-20	ses	00583


*/
/*
'00580',-
'00590',-
'00564',
'00579',-
'00584',-
'00572',-
'00576',-
'00617',-
'00569',-
'00575',-
'00554',-
'00564',----
'00566',-
'00583',-
*/
select	*
from		CSM.dbo.Organizations
where		Docket in 
(
'00580',
'00590',
'00564',
'00579',
'00584',
'00572',
'00576',
'00617',
'00569',
'00575',
'00554',
'00564',
'00566',
'00583'
)

select	*
from		SQLORD.dbo.ALL_INSTITUTIONS_RPT
where		Docket in
(
(
'00580',
'00590',
'00564',
'00579',
'00584',
'00572',
'00576',
'00617',
'00569',
'00575',
'00554',
'00564',
'00566',
'00583'
)

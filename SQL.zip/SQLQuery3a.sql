/*		ENTITY DOCUMENTS
*/
/*
SELECT
  cast(d.DocumentId as varchar(9)) + '-CSM' as  DocumentId
, d.DocCategoryTypeCode
, d.DocCategoryCode
, d.ApplicationSystemCode
, d.FileName
, d.FileExtension
, d.FileSize
, d.ContentType
, d.Description
, d.ClientFilePath
, d.Indexed
, d.Deleted
, d.LastIndexedDate
, d.Unzip
, d.IsSecure
, d.CreatedBy
, d.CreatedDate
, d.ModifiedBy
, d.ModifiedDate
, od.Docket
, 'Exam Reports/Letters' as RECORDTYPENAME
, 'CSM.dbo.Documents' as SOURCE
, dc.Description as DOCUMENT_TYPE__C
*/
SELECT	d.FileName
	,	d.Description
	,	od.Docket
FROM		CSM.dbo.Documents d
LEFT JOIN	CSM.dbo.OrganizationDocuments od 
	ON	d.DocumentId=od.DocumentId
LEFT JOIN	CSM.dbo.DocCategories dc 
	ON	d.DocCategoryTypeCode=dc.DocCategoryTypeCode 
	AND	d.DocCategoryCode=dc.DocCategoryCode
WHERE		d.Deleted=0
	AND	CHARINDEX(CHAR(37),d.FileName) > 0
/*		FIND A CFPB EMPLOYEE / USER		*/

declare	@intPersonId	int
	,	@LastName		varchar(100)
	,	@FirstName		varchar(100)
	
select	@intPersonId = 10141
--select	@LastName = char(39) + 'Garcia' + char(39)
--select	@FirstName = char(39) + 'Elena' + char(39)

select	@LastName = 'Nandan'
select	@FirstName = 'Nandan'

--	CHECK THE CORE DATABASE	  --	
select	p.PersonId
		, p.OrganizationId
		, p.PersonTypeCode
		, vpd.USERNAME
		, p.LastName
		, p.FirstName
		, p.Status
		, p.CreatedBy
		, p1.LastName
		, p.CreationDate
		, p.ModifiedBy
		, p2.LastName
		, p.ModifiedDate
		, p.UserId
from		Core.dbo.Persons p
left join	Core.dbo.Persons p1
	on	p.CreatedBy = p1.PersonId
left join	Core.dbo.Persons p2
	on	p.ModifiedBy = p2.PersonId	
left join	SQLORD.dbo.VW_PersonDetail vpd
	on	p.PersonId = vpd.PersonId	
where		p.LastName = @LastName
	--and	p.FirstName = @FirstName
	
--	CHECK SQLORD   --
/*
select 'SQLORD.dbo.VW_PersonDetail' as ThePath, * from SQLORD.dbo.VW_PersonDetail where PersonId = 14865
select 'SQLORD.dbo.VW_PersonDetail_salesforce' as ThePath, * from SQLORD.dbo.VW_PersonDetail_salesforce where PersonId = 14865	

select	*
from	
*/	
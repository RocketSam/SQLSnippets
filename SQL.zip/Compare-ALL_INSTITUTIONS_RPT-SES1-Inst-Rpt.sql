/*
	Name:	Compare Institution data across tables in SES1
	Date:	2017-05-31 (C.Palamara)
	
	Tables in Comparison:
	SQLORD.dbo.ALL_INSTITUTIONS_RPT
	SQLORD.dbo.VW_LoadViewAllInstitutionsRptIT	
	CSM.dbo.Organizations

	
*/
/*	SQLORD.dbo.ALL_INSTITUTIONS_RPT
	SQLORD.dbo.VW_LoadViewAllInstitutionsRptIT
	This view is behind the report of Active Institutions in SES1
	Comparing this view with ALL_INS
*/	
select	a.DOCKET
	,	a.ENTITY_TYPE as A_ENTITY_TYPE
	,	v.Entity_Type as V_ENTITY_TYPE
	,	a.ENTITY_STATUS as A_ENTITY_STATUS
	,	v.Entity_Status as V_ENTITY_STATUS
	,	a.MailAddress as A_MAIL_ADDRESS
	,	v.MailAddress as V_MAIL_ADDRESS
	,	a.REGION_ABV as A_REGION_ABV
	,	v.Region_Abv as V_REGION_ABV
from		SQLORD.dbo.ALL_INSTITUTIONS_RPT a
inner join	SQLORD.dbo.VW_LoadViewAllInstitutionsRptIT v
	on	a.DOCKET = v.Docket
where	  (	a.ENTITY_TYPE <> v.Entity_Type
	or	a.ENTITY_STATUS <> v.Entity_Status
	or	a.MailAddress <> v.MailAddress
	or	a.REGION_ABV <> v.Region_Abv
	  )



select	o.Docket
	,	o.TaxId as O_TaxId
	,	a.TaxId as A_TaxId
	,	o.WebSite as O_WebSite
	,	a.WWW_ADDRESS as A_WebSite
	,	o.RSSDId as O_RSSDID
	,	a.RSSDId as A_RSSDID
	,	o.MlsID as O_NMLSID
	,	a.MlsID as A_NMLSID
	,	o.OrganizationStatusCode as O_Status
	,	a.ENTITY_STATUS as A_Status
from		CSM.dbo.Organizations o
inner join	SQLORD.dbo.ALL_INSTITUTIONS_RPT a
	on	o.Docket = a.DOCKET
where	 (	o.OrganizationStatusCode <> a.ENTITY_STATUS
	or	o.TaxId <> a.TaxId
	or	o.WebSite <> a.WWW_ADDRESS
	or	o.RSSDId <> a.RSSDId
	or	o.MlsID <> a.MlsID
	)
	
select	o.Docket
	,	o.Name as O_Name
	,	a.Name as A_Name
	,	o.ShortName as O_ShortName
	,	a.ShortName as A_ShortName
	,	o.LeadRegulatorCode as O_LeadRegCode
	,	a.LeadRegulatorCode as A_LeadRegCode
	,	o.Address1 as O_Address
	,	a.ADDRESS as A_Address
	,	o.MailAddress1 as O_MailAddress
	,	a.MailAddress as A_MailAddress
from		CSM.dbo.ServiceProviders o
inner join	SQLORD.dbo.ALL_INSTITUTIONS_RPT a
	on	o.Docket = a.DOCKET
where	 (	o.Name <> a.NAME
--	or	o.ShortName <> a.ShortName
	or	o.LeadRegulatorCode <> a.LeadRegulatorCode
	or	o.Address1 <> a.ADDRESS
	or	o.MailAddress1 <> a.MailAddress
	)	
	

/*
select	*
from		CSM.dbo.Organizations

use CSM
select	TABLE_NAME, COLUMN_NAME
from		INFORMATION_SCHEMA.COLUMNS
where		COLUMN_NAME LIKE '%address%'
order by	TABLE_NAME, COLUMN_NAME

select	*
from		dbo.ServiceProviders
where		Docket = '00072'




*/
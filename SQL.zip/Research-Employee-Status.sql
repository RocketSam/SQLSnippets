/*
	Research Employee Status @ CFPB
*/	

--	declare local variables
declare	@intPersonId		integer,
		@vcNameLast		varchar(50),
		@vcNameFirst	varchar(50)
		
select	@intPersonId = 0
select	@vcNameFirst = 'Peter'
select	@vcNameLast = 'Glesius'

--	find person
select	@intPersonId = PersonId
from		Core.dbo.Persons
where		LastName = @vcNameLast
	and	FirstName = @vcNameFirst
	
select	FirstName
	,	MiddleName
	,	LastName
	,	PersonId
	,	case when [Status] = 1 then 'Active' else 'Inactive' end as [Employee Status]
from		Core.dbo.Persons
where		PersonId = @intPersonId
	and	PersonTypeCode = 'E'

/*
select	'Core.Person and Core.Organizations' as TheSource, *
from		Core.dbo.Persons p
inner join	Core.dbo.Organizations o
	on	o.OrganizationID = p.OrganizationId
where		p.PersonId = @intPersonId
*/

select	'SQLORD.VW_PersonDetail' as TheSource, *
from		SQLORD.dbo.VW_PersonDetail
where		PersonId = @intPersonId



-- END OF CODE
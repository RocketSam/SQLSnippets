select	*
from		Regulatory.dbo.Regulations
order by	Description

select	*
from		Regulatory.dbo.VW_Violations
where		RegulationId = 35



/*
Fair Credit Reporting Act (15 USC) is RegulationId = 35

*/
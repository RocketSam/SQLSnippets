/*---	ALL ABOUT A PERSON -------------------------------------
	Description:  Statements to identify an Influential
			  Party in SES1
	Date:		  2017 March 16
	Author:	  Christine Palamara
*-------------------------------------------------------------*/		
-- Find Influential Parties --
use CSM
declare	@vcSearch1		varchar(100)
	   ,	@vcSearch2		varchar(100)
	   ,	@vcValue1		varchar(100)
	   ,  @vcValue2		varchar(100)
	   ,	@intPersonId	integer
	   ,	@vcLastName		varchar(100)
	   ,	@vcFirstName	varchar(100)
	   ,	@vcUserName		varchar(100)

-- table variable to hold full database paths of all tables using PersonId		
declare	@tblFullDBPaths	table
	(	PathID int primary key IDENTITY(1,1) NOT NULL
		, FullDBPath varchar(100)
	)		
		
-- initialize variable(s)
select	@vcSearch1 = 'LastName'
select	@vcValue1 = char(39) + 'Mariam' + char(39)

select	@vcSearch2 = 'PersonId'
select	@vcValue2 = 10478

-- populate table variable
insert into	@tblFullDBPaths
	(	FullDBPath
	)
select	TABLE_CATALOG + '.' + TABLE_SCHEMA + '.' + TABLE_NAME
from		INFORMATION_SCHEMA.COLUMNS
where	  (	COLUMN_NAME = @vcSearch1
	   
	   )
group by	TABLE_CATALOG + '.' + TABLE_SCHEMA + '.' + TABLE_NAME

-- retrieve SQL statements
select	'select * from ' + FullDBPath + ' where ' + @vcSearch1 + ' = ' + @vcValue1 
--+  ' or ' + @vcSearch2 + ' = ' + @vcValue2 + ';'
from		@tblFullDBPaths


-- paste output here 
/*
select * from CSM.dbo.People where LastName = 'Mariam'
select * from SQLORD.dbo.InfluentialParties where LastName = 'Mariam'

select * from CSM.dbo.OrganizationPeopleTitles where PersonId = 3300 and Docket = '00093'
select * from CSM.dbo.OrganizationPeoplePhoneNumbers where PhoneTypeCode = 'M' and PersonId = 3300 and Docket = '00093'

*/
/*	OUTPUT SECTION
Influential Parties are located:
	CSM.dbo.People (select * from CSM.dbo.People where LastName = 'Chadwell';)
	SQLORD.dbo.InfluentialParties (select * from SQLORD.dbo.InfluentialParties where LastName = 'Chadwell';)
	* * * they are not located in Core * * *
Contact Record Types in SF:
	Entity Contact
	Associate
	Government
Mobile Phone Number is in CSM.dbo.OrganizationPeoplePhoneNumbers
	
*/
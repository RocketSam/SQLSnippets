/*		MILESTONES QUERY FOR UNIT TESTING
*/

select	DOCKET,
		EXAM_TYPE,
		ExaminationId,
		--ARCMemoFinalDate as [ARC Memo to SEFL Assoc Director],
		--ARCDecisionDate as [ARC SEFL Assoc Director Decision Date],
		--ARDApprovalDate as [ARD Approval],
		--CommHQRGDate2 as [Comments HQ to Region - 2nd Review],
		--CommHQRGDate3 as [Comments HQ to Region - 3rd Review],
		DraftHQDistribution as [Draft HQ Distribution],
		DraftRGHQDate as [Draft Region to HQ]
from		dbo.EDS_SUMMARY_RPT
where		ExaminationId in (2306, 493, 1880)

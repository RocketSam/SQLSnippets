/*	More analysis of Institutional Product Line

SQL from Pentaho script for insert into IPL__C

SELECT	PrimaryKey
		, PrimaryKeyType
		, 'FollowUpId' + cast(FollowUpID as varchar(10))+'_' + PrimaryKey + '_' + ReasonCode as FollowupId
		, FollowUpIDType
		, CategoryCode
		, CategoryDesc
		, SourceDesc
		, ReasonCode
		, ReasonDesc
		, ReasonGroupDesc
		, ReasonTypeCode
		, ReasonTypeCodeDesc
		, Comment
		, DueDate
		, DueYearQtr
		, CloseDate
		, CloseYearQtr
		, CreatedBy
		, CreatedDate
		, ModifiedBy
		, ModifiedDate
		, IsMRA
		, IsMRAOpen
		, IsMRAClosed
		, IsNonMRA
		, IsNonMRAOpen
		, IsNonMRAClosed
		, BSAExamined
		, BSANotExamined
		, IsBSA
		, IsBSAOpen
		, IsBSAClosed
		, IsDueAtNextExam
		, ExaminationId
		, Exam_Type
		, Start_Date
		, RADId
		, Docket
		, Entity_Type
		, Entity_Type_Desc
		, InstName
		, InstStreet
		, InstCity
		, InstState
		, InstRegion
		, WebSiteURL
		, SubregionCode
		, SubregionShortName
		, SubregionLongName
		, SubRegionStatus
		, DocketStatusCode
		, DocketStatusCodeDescription
		, InstRegionAbbrev
		, InstRegionName
FROM		SQLORD.dbo.vw_Followups 
WHERE		ReasonGroupDesc='Institutional Product Line'
ORDER BY	FollowupId

*/

SELECT	  DISTINCT
		  Docket
		, InstName as [Institution Name]
		, ReasonCode as [Reason Code]
		, ReasonDesc as [Reason Description]
		, ReasonGroupDesc as [Reason Group Description]
		, ReasonTypeCode as [Reason Type Code]
		, DocketStatusCode as [Docket Status]
		, Entity_Type_Desc as [Entity Type]
FROM	(	SELECT  PrimaryKey
			, PrimaryKeyType
			, 'FollowUpId' + cast(FollowUpID as varchar(10))+'_' + PrimaryKey + '_' + ReasonCode as FollowupId
			, FollowUpIDType
			, CategoryCode
			, CategoryDesc
			, SourceDesc
			, ReasonCode
			, ReasonDesc
			, ReasonGroupDesc
			, ReasonTypeCode
			, ReasonTypeCodeDesc
			, Comment
			, DueDate
			, DueYearQtr
			, CloseDate
			, CloseYearQtr
			, CreatedBy
			, CreatedDate
			, ModifiedBy
			, ModifiedDate
			, IsMRA
			, IsMRAOpen
			, IsMRAClosed
			, IsNonMRA
			, IsNonMRAOpen
			, IsNonMRAClosed
			, BSAExamined
			, BSANotExamined
			, IsBSA
			, IsBSAOpen
			, IsBSAClosed
			, IsDueAtNextExam
			, ExaminationId
			, Exam_Type
			, Start_Date
			, RADId
			, Docket
			, Entity_Type
			, Entity_Type_Desc
			, InstName
			, InstStreet
			, InstCity
			, InstState
			, InstRegion
			, WebSiteURL
			, SubregionCode
			, SubregionShortName
			, SubregionLongName
			, SubRegionStatus
			, DocketStatusCode
			, DocketStatusCodeDescription
			, InstRegionAbbrev
			, InstRegionName
	FROM		SQLORD.dbo.vw_Followups 
	WHERE		ReasonGroupDesc='Institutional Product Line'
	)x
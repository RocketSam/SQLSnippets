select  distinct ps.CFPBId, p.personstatus,pe.EmailAddress,p.PersonStatus, ps.personid, p.lastname, p.firstname, p.username, p.personstatus, p.UsernameStatus, p.jobdescription 
from core.dbo.vw_secauth_all s
inner join core.dbo.vw_persondetail p
on p.personid =s.personid
inner join	core.dbo.Persons ps
	on	s.PersonId = ps.PersonId
left join  Core.dbo.PersonEmailAddresses pe
	on	ps.PersonId = pe.PersonId
and p.jobdescription is not null
and p.persontypecode <> 'S'


--and p.personstatus =1 

declare	@docket	as varchar(5)

select	@docket = '00259'

PRINT		'SQLORD.dbo.EDS_SUMMARY_RPT:'

IF   
	(SELECT COUNT(*) FROM SQLORD.dbo.EDS_SUMMARY_RPT WHERE DOCKET = @docket) = 0
	PRINT 'No records for Docket: ' + @docket
ELSE 
	select	'SQLORD.dbo.EDS_SUMMARY_RPT' as 'Source'
		,	*
	from		SQLORD.dbo.EDS_SUMMARY_RPT
	where		DOCKET = @docket	
GO  

PRINT		'SQLORD.dbo.VW_RADActionsFlat:'

IF   
	(SELECT COUNT(*) FROM SQLORD.dbo.VW_RADActionsFlat WHERE DOCKET = @docket) = 0
	PRINT 'No records for Docket: ' + @docket
ELSE 
	select	'SQLORD.dbo.VW_RADActionsFlat' as 'Source'
		,	*
	from		SQLORD.dbo.VW_RADActionsFlat
	where		DOCKET = @docket	
GO  

select	*
from		SQLORD.dbo.RADAgainst
where		AgainstName = '00259'

select	*
from		CSM.dbo.OrganizationDocuments
where		Docket = '00259'


select	so.name
	,	so.modify_date
from		sys.objects as so
inner join  INFORMATION_SCHEMA.TABLES as ist
	on	ist.TABLE_NAME = so.name
where		so.name = '[table]'
order by    so.modify_date desc;

use Regulatory
select	distinct TABLE_NAME
from		INFORMATION_SCHEMA.COLUMNS
where		COLUMN_NAME = 'Docket'

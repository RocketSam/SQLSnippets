/*		SchedActivityEndDate
*/

declare @tblPersons table(PersonID int)
insert into @tblPersons values (9908)
--insert into @tblPersons values (9908)

declare @tblExaminations table(ExaminationID int)
insert into @tblExaminations values (395)
--insert into @tblExaminations values (395)

/*
declare	@intPersonId	integer,
		@intExaminationId	integer
		
select	@intPersonId = 9008,
		@intExaminationId = 395
*/
		
select	*
from		Regulatory.dbo.VW_ScheduledEmployees 
inner join	Regulatory.dbo.VW_PersonDetail
	on	Regulatory.dbo.VW_ScheduledEmployees.PersonID = Regulatory.dbo.VW_PersonDetail.PersonId
where		Regulatory.dbo.VW_ScheduledEmployees.ExaminationID in (select ExaminationID from @tblExaminations)	
	and	Regulatory.dbo.VW_PersonDetail.PersonID in (select PersonID from @tblPersons)
	

select	*
from		Regulatory.dbo.VW_PersonDetail
where		PersonId = 9007

	
		
				
select	ExaminationID
		,PersonID
		,MIN(SchedActivityStartDate) as MinStartDate
		,MAX(SchedActivityEndDate) as MaxStartDate
from		Regulatory.dbo.VW_ScheduledEmployees
where		PersonID in (select PersonID from @tblPersons)	
	and	ExaminationID in (select ExaminationID from @tblExaminations)
group by	ExaminationID,
		PersonID	
		
-- the following query is has been copied from the Pentaho job_CFPB_Bulk_Load.kjb step trans_create_case_team_member.ktr, then aggregated to show MIN and MAX dates --	
SELECT	vse.ActivityTypeCode
		,vse.PersonID
		,vse.ActivityCode
		,vse.ActivityCodeDescription
		,vse.Comment
		,vse.ExaminationID
		,vse.ContactPhone
		,vse.EstimatedDays
		,MIN(vse.SchedActivityStartDate) as MinStartDate
		,MAX(vse.SchedActivityEndDate) as MaxEndDate
		,vse.ActivityID
		,vpd.LastName + ',' + vpd.FirstName FULLNAME__C
		,vpd.LastName + ',' + vpd.FirstName NAME
		,vpd.Username
		,vpd.JobDescription
		,CASE 
			WHEN (MAX(vse.SchedActivityEndDate) >= GETDATE()) 
				THEN 'TRUE' 
			ELSE 
				'FALSE' 
		END as ACTIVE__C
FROM		Regulatory.dbo.VW_ScheduledEmployees vse
JOIN		Regulatory.dbo.VW_PersonDetail vpd 
	ON	vse.PersonId=vpd.PersonId
where		vse.ExaminationID is not null  
and	vse.PersonId in (select PersonID from @tblPersons)
and	ExaminationID in (select ExaminationID from @tblExaminations)
group by	vse.ActivityTypeCode
		,vse.PersonID
		,vse.ActivityCode
		,vse.ActivityCodeDescription
		,vse.Comment
		,vse.ExaminationID
		,vse.ContactPhone
		,vse.EstimatedDays
		,vse.ActivityID
		,vpd.LastName + ',' + vpd.FirstName
		,vpd.LastName + ',' + vpd.FirstName
		,vpd.Username
		,vpd.JobDescription
order by	vse.ExaminationID, vse.PersonId	
			
	
		

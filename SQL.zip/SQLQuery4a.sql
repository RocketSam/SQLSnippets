select	MAX(ExaminationId) as MaxExamNumber
from		Regulatory.dbo.Examination



select	*
from		Regulatory.dbo.Examination
where		ExaminationId = 2766

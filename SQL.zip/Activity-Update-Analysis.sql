--	declare local variables
declare	@intPerson integer,
		@intExaminationId integer,
		@strNameLast varchar(50),
		@strNameFirst varchar(50)
		
select	@intExaminationId = 876


--	find Vincent Agusta
select	@intPerson = PersonId
		, @strNameLast = LastName
		, @strNameFirst = FirstName
from		Core.dbo.Persons
where		LastName = 'Zurbuchen'
	and	FirstName = 'Mark'

print 'Exam: ' + cast(@intExaminationId as varchar(10))
print 'PersonID: ' + cast(@intPerson as varchar(10))
print 'Name: ' + @strNameFirst + ' ' + @strNameLast

select	*
from		Regulatory.dbo.VW_ScheduledEmployees
where		PersonID = @intPerson
	and	ExaminationID = @intExaminationId
order by	SchedActivityStartDate, SchedActivityEndDate
	
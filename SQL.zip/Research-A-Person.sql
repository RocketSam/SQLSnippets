/*---	ALL ABOUT A PERSON -------------------------------------
	Description:  Statements to identify a Person in SES1
			  May be an Employee, Contractor, Case
			  Team Member
	Date:		  2017 March 15
	Author:	  Christine Palamara
	How to use:   Switch databases [line 16] to search for people using column names and values [lines 31,32].
	Possible data to use for searching:
	First Name
	Last Name
	Person ID
	User Name
	
*-------------------------------------------------------------*/		
-- Do Influential Parties and Employees --
use Core
declare	@vcSearch1		varchar(100)
	   ,	@vcSearch2		varchar(100)
	   ,	@vcValue1		varchar(100)
	   ,  @vcValue2		varchar(100)
	   ,	@intPersonId	integer
	   ,	@vcLastName		varchar(100)
	   ,	@vcFirstName	varchar(100)
	   ,	@vcUserName		varchar(100)

-- table variable to hold full database paths of all tables using PersonId		
declare	@tblFullDBPaths	table
	(	PathID int primary key IDENTITY(1,1) NOT NULL
		, FullDBPath varchar(100)
	)		
		
-- initialize variable(s)
select	@vcSearch1 = 'PersonId'
--select	@vcValue1 = char(39) + 'Anderson' + char(39)
select	@vcValue1 = 12387

--select	@vcSearch2 = 'LastName'
--select	@vcValue2 = 'Blasetti'

-- populate table variable
insert into	@tblFullDBPaths
	(	FullDBPath
	)
select	TABLE_CATALOG + '.' + TABLE_SCHEMA + '.' + TABLE_NAME
from		INFORMATION_SCHEMA.COLUMNS
where	  (	COLUMN_NAME = @vcSearch1
	   --or	COLUMN_NAME = @vcSearch2
	   )
group by	TABLE_CATALOG + '.' + TABLE_SCHEMA + '.' + TABLE_NAME

-- retrieve SQL statements
--select	'select * from ' + FullDBPath + ' where ' + @vcSearch + ' = ' + char(39) + @vcValue + char(39) + ';'
--from		@tblFullDBPaths

select	'select ' + char(39) + FullDBPath + char(39) + ' as ThePath, * from ' + FullDBPath + ' where ' + @vcSearch1 + ' = ' + @vcValue1 
--+  ' and ' + @vcSearch2 + ' = ' + @vcValue2 + ';'
from		@tblFullDBPaths


--select 'Core.dbo.PersonEmailAddresses' as ThePath, * from Core.dbo.PersonEmailAddresses where PersonId = 12625


-- paste output here 
/*
select 'Core.dbo.Alias' as ThePath, * from Core.dbo.Alias where PersonId = 12387
select 'Core.dbo.PerfPersonAccess' as ThePath, * from Core.dbo.PerfPersonAccess where PersonId = 12387
select 'Core.dbo.PersonAddresses' as ThePath, * from Core.dbo.PersonAddresses where PersonId = 12387
select 'Core.dbo.PersonAWSSchedule' as ThePath, * from Core.dbo.PersonAWSSchedule where PersonId = 12387
select 'Core.dbo.PersonCodes' as ThePath, * from Core.dbo.PersonCodes where PersonId = 12387
select 'Core.dbo.PersonContactInfo' as ThePath, * from Core.dbo.PersonContactInfo where PersonId = 12387
select 'Core.dbo.PersonDates' as ThePath, * from Core.dbo.PersonDates where PersonId = 12387
select 'Core.dbo.PersonDeleteLog' as ThePath, * from Core.dbo.PersonDeleteLog where PersonId = 12387
select 'Core.dbo.PersonEmailAddresses' as ThePath, * from Core.dbo.PersonEmailAddresses where PersonId = 12387
select 'Core.dbo.PersonPhoneNumbers' as ThePath, * from Core.dbo.PersonPhoneNumbers where PersonId = 12387
select 'Core.dbo.PersonRegionCorrection' as ThePath, * from Core.dbo.PersonRegionCorrection where PersonId = 12387
select 'Core.dbo.Persons' as ThePath, * from Core.dbo.Persons where PersonId = 12387
select 'Core.dbo.SaveQuery' as ThePath, * from Core.dbo.SaveQuery where PersonId = 12387
select 'Core.dbo.tmpCodes_ERH' as ThePath, * from Core.dbo.tmpCodes_ERH where PersonId = 12387
select 'Core.dbo.UserNames' as ThePath, * from Core.dbo.UserNames where PersonId = 12387
--select 'Core.dbo.vBBUserData' as ThePath, * from Core.dbo.vBBUserData where PersonId = 12387
select 'Core.dbo.VW_EmergencyContacts' as ThePath, * from Core.dbo.VW_EmergencyContacts where PersonId = 12387
select 'Core.dbo.VW_EmployeesDetail' as ThePath, * from Core.dbo.VW_EmployeesDetail where PersonId = 12387
select 'Core.dbo.VW_PARVWALL_Users' as ThePath, * from Core.dbo.VW_PARVWALL_Users where PersonId = 12387
select 'Core.dbo.VW_PerfPersonAccess' as ThePath, * from Core.dbo.VW_PerfPersonAccess where PersonId = 12387
select 'Core.dbo.VW_PersonDetail' as ThePath, * from Core.dbo.VW_PersonDetail where PersonId = 12387
select 'Core.dbo.VW_PersonDetail_salesforce' as ThePath, * from Core.dbo.VW_PersonDetail_salesforce where PersonId = 12387
select 'Core.dbo.VW_PersonPhoneNumbers' as ThePath, * from Core.dbo.VW_PersonPhoneNumbers where PersonId = 12387
select 'Core.dbo.VW_Persons' as ThePath, * from Core.dbo.VW_Persons where PersonId = 12387
select 'Core.dbo.VW_PersonUserName' as ThePath, * from Core.dbo.VW_PersonUserName where PersonId = 12387
select 'Core.dbo.VW_SecAuth' as ThePath, * from Core.dbo.VW_SecAuth where PersonId = 12387
select 'Core.dbo.VW_SecAuth_All' as ThePath, * from Core.dbo.VW_SecAuth_All where PersonId = 12387
select 'Core.dbo.VW_SecTrainingList' as ThePath, * from Core.dbo.VW_SecTrainingList where PersonId = 12387
select 'Core.dbo.VW_UserNamesApplSysApplRoles' as ThePath, * from Core.dbo.VW_UserNamesApplSysApplRoles where PersonId = 12387

*/

/*	OUTPUT SECTION
Influential Parties are located:
	CSM.dbo.People (select * from CSM.dbo.People where LastName = 'Chadwell';)
	SQLORD.dbo.InfluentialParties (select * from SQLORD.dbo.InfluentialParties where LastName = 'Chadwell';)
	* * * they are not located in Core * * *
*/
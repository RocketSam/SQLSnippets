select	s.DOCKET
		, s.ExaminationId
		, s.EXAM_TYPE
		, s.GPRADeadline
		, s.MAIL_DATE
		, m.*
from		SQLORD.dbo.EDS_SUMMARY_RPT s
inner join	SQLORD.dbo.EDS_MISC_RPT m
	on	s.DOCKET = m.Docket
	and	s.ExaminationId = m.ExaminationId
where		s.EXAM_TYPE = 12
	--	s.EXAM_TYPE in (10, 12, 16, 17)
	and	s.OnSiteReviewCompl = ''
	--and (	s.GPRADeadline <> '' or s.MAIL_DATE <> '')
	--and	s.MAIL_DATE > '2016-12-23'
	--and	m.ScheduledComplDate > '2016-12-23'
	
order by	m.ScheduledComplDate desc
/*
	SFSES-1532: Deleted Assignment Tracker Records
	
	Per Jami Blume 2017-01-19: Provide Core Team a list of Deleted Records that didn't make it to Assignment Tracker
	Data we have to work with:
	Employee: Vincent Agusta
	Docket: 55
	Exam: 1406
	Start Date: May 26 2014
	Deleted Date: Aug 6 2014
	Pay Period Begin Date(s): Jul 13 2014 (2 records); Jul 27 2014 (2 records)
*/	

--	declare local variables

declare	@intPerson integer,
		@intExaminationId integer
		
--select	@intExaminationId = 847
--select	@intExaminationId = 1406

--	find Vincent Agusta
select	@intPerson = PersonId
from		Core.dbo.Persons
where		LastName = 'Sanford'
	and	FirstName = 'Paul'
	
print @intPerson	
	

select	'Reg.PARData' as TheSource, *
from		Regulatory.dbo.PARData
where		PersonId = @intPerson
	--and	( PayPeriodBeginDate = '2014-07-13'
	--	or PayPeriodBeginDate = '2014-07-27'
	--	)
--	and	PARDataId = 7671

select	'View' as TheSource, *
from		SQLORD.dbo.vw_ParDetailSummarized_By_ExamActivityUser
where		
--ExaminationId = @intExaminationId
	--and	
	UserId = @intPerson
	
select	'VW_ExamPARHoursExist' as TheSource, *
from		SQLORD.dbo.VW_ExamPARHoursExist
--where		ExaminationID = @intExaminationId
	
		
select	'Reg.Examination' as TheSource
		, ExaminationId
		, DeletedDate
		, DeletedSysDate
from		Regulatory.dbo.Examination
--where		ExaminationId = @intExaminationId
/*where		ExaminationId in (560,
615,
825,
835,
844,
857,
1248,
1270,
1406,
1255,
1806,
1693,
1686,
1705,
1866,
1690,
2128,
2223,
2269,
1865,
2257,
2264,
2855)
order by	ExaminationId
*/
select	'Reg.PARHours' as TheSource, *
from		Regulatory.dbo.PARHours
--where		ExaminationId = @intExaminationId
where		CreatedBy = @intPerson

select	'SQLORD.PARDetail' as TheSource, *
from		SQLORD.dbo.PARDetail
where		--ExaminationId = @intExaminationId
	--and	
	UserId = @intPerson
	and	ExaminationId is null
	and	Docket is null
order by	Detail_Type, Activity_Code_Desc	

select	*
from		SQLORD.dbo.PARDetail
where		UserId = 9052
	and	Docket is null
	and	ExaminationId is null
	and	Detail_Type = 'A'
	and	Activity_Code_Desc = 'Travel'
order by	DetailKey
--DetailKey = 103755

	
	
	

select	pd.UserId
		, p.FirstName
		, p.LastName
		, pd.ExaminationId
		, pd.Job_Code
		, pd.Job_Code_Desc
		, pd.Activity_Code
		, pd.Activity_Code_Desc
		, pd.Docket
from		Core.dbo.Persons p
inner join	SQLORD.dbo.PARDetail pd
	on	pd.UserId = p.PersonId
inner join	Regulatory.dbo.Examination e
	on	pd.ExaminationId = e.ExaminationId
where		e.DeletedDate is not null
	and	pd.UserId = @intPerson
order by	pd.ExaminationId
		, p.PersonId
		

	
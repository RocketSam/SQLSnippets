
declare <cursor_name, sysname, test_cursor> cursor
read_only
for <select_statement, , select au_fname from pubs.dbo.authors>

declare @name varchar(40)
open <cursor_name, sysname, test_cursor>

fetch next from <cursor_name, sysname, test_cursor> into @name
while (@@fetch_status <> -1)
begin
	if (@@fetch_status <> -2)
	begin
--		print 'add user defined code here'
--		eg.
		declare @message varchar(100)
		select @message = 'my name is: ' + @name
		print @message
	end
	fetch next from <cursor_name, sysname, test_cursor> into @name
end

close <cursor_name, sysname, test_cursor>
deallocate <cursor_name, sysname, test_cursor>
go


declare	@tblDataCheck as table
	(	vcDataName	varchar(100)
	,	vcDb		varchar(100)
	,	vcDev1	varchar(100)
	)

insert into @tblDataCheck
	(	vcDataName
	,	vcDb
	)
values (	'ALL_INSTITUTIONS_RPT'
	,	'SQLORD'
	)		
	
	
select	*
from		Regulatory.dbo.Examination
where		ExaminationId = 4029
	
/*	SQLORD.dbo.RADIPLS  (110 rows)
	RADID					integer
	IPLCode				varchar(10)
	IPLDescription			varchar(30)
*/	
select	'SQLORD.dbo.RADIPLS' as Table_Name
		, 'SELECT *' as Query_Type
		, *
from		SQLORD.dbo.RADIPLS

-- validate count of IPLs --
select	'SQLORD.dbo.RADIPLS' as Table_Name
		, 'COUNT(DISTINCT IPLCode)' as Query_Type
		, COUNT(DISTINCT IPLCode) as Count_Distinct_IPLCode
from		SQLORD.dbo.RADIPLS

select	'SQLORD.dbo.RADIPLS' as Table_Name
		, 'GROUP BY IPLCode and IPLDescription' as Query_Type
		, IPLCode
		, IPLDescription
from		SQLORD.dbo.RADIPLS
group by	IPLCode
		, IPLDescription
		
select	'SQLORD.dbo.RADIPLS' as Table_Name
		, 'COUNT CONCAT IPLCode and IPLDescription' as Query_Type
		, COUNT(DISTINCT IPLCode + IPLDescription) as Count_Distinct_Concat
from		SQLORD.dbo.RADIPLS

-- check count of IPLs per RADID
select	'SQLORD.dbo.RADIPLS' as Table_Name,
		RADID,
		COUNT(DISTINCT IPLCode) as Count_IPLCode_Per_RADID
from		SQLORD.dbo.RADIPLS
group by	RADID
order by	Count_IPLCode_Per_RADID Desc	


-----------------------------------------------------------
/*	Regulatory.dbo.VW_RADIPLs  (110 rows)
	RADId					integer
	Docket				5-character Docket Number 
	ActionCode				varchar(10)
	ActionDescription			varchar(30)
	IPLCode				varchar(10)
	IPLDescription			varchar(30)
*/	
select	'Regulatory.dbo.VW_RADIPLs' as Table_Name
		, 'SELECT STAR' as Query_Type
		, *
from		Regulatory.dbo.VW_RADIPLs
	
-- check combinations of Docket-to-IPL	
select	DISTINCT 'Regulatory.dbo.VW_RADIPLs' as Table_Name
		, 'DISTINCT ROW' as Query_Type
		, Docket as Distinct_Docket
		, IPLCode
		, IPLDescription
from		Regulatory.dbo.VW_RADIPLs

select	'Regulatory.dbo.VW_RADIPLs' as Table_Name,
		'Group By Docket, IPLCode, IPLDescription' as Query_Type,
		Docket
		, IPLCode
		, IPLDescription
from		Regulatory.dbo.VW_RADIPLs
group by	Docket
		,IPLCode
		,IPLDescription

-- list all Docket-To-IPL combinations with Institution name (Inner Join ALL_INSTITUTIONS_RPT) 
SELECT	DISTINCT 'Regulatory.dbo.VW_RADIPLs JOIN SQLORD.dbo.ALL_INSTITUTIONS_RPT' as Table_Names
		, 'DISTINCT rows' as Query_Type
		, v.Docket
		, a.NAME as Institution_Name
		, v.IPLCode
		, v.IPLDescription
FROM		Regulatory.dbo.VW_RADIPLs v
INNER JOIN	SQLORD.dbo.ALL_INSTITUTIONS_RPT a
	ON	v.Docket = a.DOCKET
ORDER BY	v.Docket

SELECT	'Regulatory.dbo.VW_RADIPLs JOIN SQLORD.dbo.ALL_INSTITUTIONS_RPT' as Table_Names
		, 'Group By Columns' as Query_Type
		, v.Docket
		, a.NAME as Institution_Name
		, v.IPLCode
		, v.IPLDescription
FROM		Regulatory.dbo.VW_RADIPLs v
INNER JOIN	SQLORD.dbo.ALL_INSTITUTIONS_RPT a
	ON	v.Docket = a.DOCKET
GROUP BY	v.Docket
		, a.NAME
		, v.IPLCode
		, v.IPLDescription	
ORDER BY	v.Docket

SELECT	DISTINCT Docket
FROM		Regulatory.dbo.VW_RADIPLs
-- 67 rows --

SELECT	DISTINCT v.Docket
		, a.[NAME]
FROM		Regulatory.dbo.VW_RADIPLs v
INNER JOIN	SQLORD.dbo.ALL_INSTITUTIONS_RPT a
	ON	v.Docket = a.DOCKET
-- 67 rows to validate inner join is ok

SELECT	DISTINCT 'Regulatory.dbo.VW_RADIPLs' as Table_Name
		, 'DISTINCT IPLCode' as Query_Type
		, IPLCode
FROM		Regulatory.dbo.VW_RADIPLs
	
-------------------------------------------------------------	
/*	Regulatory.dbo.VW_RADIPLsConcatenated  (98 rows)
	RADId					integer
	Docket				char(5)
	ActionCode				varchar(10)
	ActionDescription			varchar(30)
	IPLCodes				nvarchar(max)
*/	
select	'Regulatory.dbo.VW_RADIPLsConcatenated' as Table_Name,* 
from		Regulatory.dbo.VW_RADIPLsConcatenated
order by	RADId

select	'Regulatory.dbo.VW_RADIPLsConcatenated' as Table_Name,
		COUNT(DISTINCT RADId) as Count_RADId
from		Regulatory.dbo.VW_RADIPLsConcatenated

select	'Regulatory.dbo.VW_RADIPLsConcatenated' as Table_Name,*
from		Regulatory.dbo.VW_RADIPLsConcatenated
where		RADId = 88

select	DISTINCT 'Regulatory.dbo.VW_RADIPLsConcatenated' as Table_Name
		, Docket as Distinct_Docket
		, IPLCodes as IPLDesc_Concat
from		Regulatory.dbo.VW_RADIPLsConcatenated
order by	Docket


-------------------------------------------------------------
/*		MISCELLANEOUS ANALYSIS

select	rd.RADId
		, rd.Docket
from		Regulatory.dbo.VW_RADDocket rd
inner join	Regulatory.dbo.VW_RADIPLs ri
	on	rd.RADId = ri.RADId
	and	rd.Docket = ri.Docket
	
select	distinct CodeId
from		Regulatory.dbo.RADCodes
	


----- check for existence of 'IPL' in any column_name
USE Regulatory
select	*
from		INFORMATION_SCHEMA.COLUMNS
where		COLUMN_NAME like '%RAD%'
order by	TABLE_NAME, COLUMN_NAME

USE SQLORD
select	*
from		INFORMATION_SCHEMA.COLUMNS
where		COLUMN_NAME like '%RAD%'
order by	TABLE_NAME, COLUMN_NAME

*/

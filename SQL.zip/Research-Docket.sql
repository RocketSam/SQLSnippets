/***	DOCKET CHECK  ***/

declare	@charDOCKET	char(5),
		@intDOCKET integer,
		@vcNAME varchar(75),
		@vcEntSts varchar(1)
		
select	@charDOCKET = '00171'

select	@charDOCKET =	DOCKET
	,	@vcNAME	=	[NAME]
	,	@vcEntSts	=	ENTITY_STATUS
	,	@intDOCKET	=	CAST(DOCKET as integer)
from		SQLORD.dbo.ALL_INSTITUTIONS_RPT
where		DOCKET = @charDOCKET

print		'Source: SQLORD.dbo.ALL_INSTITUTIONS_RPT'
print		'Docket: ' + @charDOCKET
print		'Name:   ' + @vcNAME
print		'Status: ' + @vcEntSts
print		'---------------------------------------------------------'

select	@charDOCKET =	o.Docket
	,	@vcNAME	=	sp.[NAME]
	,	@vcEntSts	=	o.OrganizationStatusCode
	,	@intDOCKET	=	CAST(o.Docket as integer)
from		CSM.dbo.Organizations o
left join	CSM.dbo.ServiceProviders sp
	on	o.Docket = sp.Docket
where		o.Docket = @charDOCKET

print		'Source: CSM.dbo.Organizations'
print		'Docket: ' + @charDOCKET
print		'Name:   ' + @vcNAME
print		'Status: ' + @vcEntSts
print		'---------------------------------------------------------'

select	@charDOCKET =	v.Docket
	,	@vcNAME	=	v.[NAME]
	,	@vcEntSts	=	v.Entity_Status
	,	@intDOCKET	=	CAST(v.Docket as integer)
from		SQLORD.dbo.VW_LoadViewAllInstitutionsRptIT v
where		v.Docket = @charDOCKET

print		'Source: SQLORD.dbo.VW_LoadViewAllInstitutionsRptIT'
print		'Docket: ' + @charDOCKET
print		'Name:   ' + @vcNAME
print		'Status: ' + @vcEntSts
print		'---------------------------------------------------------'





	

		
/*
SELECT *
  FROM Regulatory.dbo.WorkPapers
WHERE WorkPaperId IN (18445,95185)
*/
/*
select	COUNT(WorkPaperId) as Count_WorkPaperId
from		Regulatory.dbo.WorkPapers



select	SUBSTRING([FileName],70,1) as Sub701
	,	ASCII(SUBSTRING([FileName],70,1)) as SpecChar
	,	[FileName]
	,	WorkPaperId
	,	ExaminationId
from		Regulatory.dbo.WorkPapers
where		WorkPaperId = 18445	

910-00_00100_Regions_Mtg Servi
cing CMS_Servicing Procedures_
Cust Svc_107-20_Escalation of Complaints - Phone Unit.doc_20120611.com.pdf

select	CHAR(194) as test
	,	WorkPaperId
	,	ExaminationId
	,	[FileName]
from		Regulatory.dbo.WorkPapers
where		CHARINDEX(CHAR(194),[FileName]) > 0
*/
/*	DOCUMENTS	*/
select	DocumentId
	,	DocCategoryCodeId
	,	ApplicationSystemId
	,	[FileName]
from		Regulatory.dbo.Documents
where		CHARINDEX([FileName],CHAR(138),0) > 0

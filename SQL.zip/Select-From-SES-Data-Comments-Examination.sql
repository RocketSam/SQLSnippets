SELECT	top 100 ec.CommentId
		,ct.ShortCode	
		,Replace(ec.Comment, char(13)+char(10), '. ') as Comment
		,ec.CommentTypeId
		, '' as Docket
		,'' as RESTITUTION__C
		, '' as ISSUE_VIOLATION__C
		,ec.ExaminationId
		,ec.ViolationId
		,ec.NATSId
		,ec.ActionId
		,ec.CreatedBy
		,ec.CreatedDate
		,ec.ModifiedBy
		,ec.ModifiedDate	
		,ct.Description
		,'Examination' as ObjectType
FROM		Regulatory.dbo.ExaminationComments ec
JOIN		SQLORD.dbo.EDS_SUMMARY_RPT esr 
	ON	ec.ExaminationId=esr.ExaminationId
LEFT JOIN	Regulatory.dbo.CommentType ct 
	ON	ec.CommentTypeId = ct.CommentTypeId
--WHERE		ct.CommentTypeId IS NULL	
ORDER BY	esr.Docket, ec.ExaminationId
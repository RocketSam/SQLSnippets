select	top 10 DocumentId
		, ApplicationSystemId
		, FileName
		, Description
		-- , Document <-- this is where the Base64 is stored
		, FileSize
from		Regulatory.dbo.Documents
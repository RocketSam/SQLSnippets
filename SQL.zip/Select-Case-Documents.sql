select	w.WorkPaperId
		, w.ExaminationId
		, w.SupplExamDocId
		, d.[Description] as Document_Description__c
		, s.SupplExamDocName as Document_Type__c
		, w.[FileName]
		, w.[Description] as Workpaper_Description
from		Regulatory.dbo.WorkPapers w
inner join	Regulatory.dbo.Documents d
	on	w.SupplExamDocId = d.DocumentId
inner join	Regulatory.dbo.SupplExamDoc s
	on	w.SupplExamDocId = s.SupplExamDocId	
where		w.ExaminationId = 1303	
/*	

*/
declare	@inExaminationId		integer
	,	@SFStatus			varchar(100)
	,	@intExamType		integer
	
 





--	Create Temp Table of Exam(s) to research	
declare	@intExamID		integer
		, @vcExamType	varchar(2)

select	@intExamID = 2692

drop table #Exam_Docket

select	eds.ExaminationId
	,	eds.DOCKET
	,	eds.REGION_ABV
into		#Exam_Docket	
from		SQLORD.dbo.EDS_SUMMARY_RPT eds
inner join	Core.dbo.OrganizationDockets od
	on	eds.DOCKET = od.Docket
inner join	Core.dbo.Organizations o
	on	o.OrganizationId = od.OrganizationId
inner join	Core.dbo.DocketStatuses ds
	on	od.DocketStatusCode = ds.DocketStatusCode	
where		eds.ExaminationId in (2674,2755)	
/*where	(	(	eds.EXAM_TYPE in (10,12,16,17,20,21)
		and	eds.MAIL_DATE is not null
		and	eds.MAIL_DATE < '2015-02-15'
		)
	  or	(	eds.EXAM_TYPE in (11,15,30)
		)
	  or	(	eds.EXAM_TYPE in (31)
		and	eds.DraftToPRDate is not null
		and	eds.DraftToPRDate < '2015-02-15'
		)
	)
*/



/*	DEV AREA

select	top 100 *
from		Regulatory.dbo.Examination
where		ExaminationId in (2674,2755)



select	EXAM_TYPE
		, COUNT(Distinct ExaminationId) as CountExamsPerType
from		EDS_SUMMARY_RPT
group by	EXAM_TYPE
order by	EXAM_TYPE

select	ExaminationId
		--, AMENDED_DATE
		--, AMENDED_SYS_DATE
		--, ARCDecisionDate
		--, ARCExecutionDate
		--, ARCMemoFinalDate
		--, ARDApprovalDate
		--, CommHQRGDate
		--, CommHQRGDate2
		--, CommHQRGDate3
		--, CommHQRGSysDate
		, COMPL_DATE
		, CRA_RELEASE_DATE
		, DatetoAssocDir
		, DatetoExamAsstDir
		, DatetoExaminations
		, DatetoOFLEO
		, DatetoOFLEOFinalRev
		, DatetoPolicy
		, DatetoPolicyAsstDir
		, DraftFrPRDate
		, DraftFrPRSysDate
		, DraftHQDistribution
		, DraftRGHQDate
		, DraftRGHQDate2
		, DraftRGHQDate3
		, DraftRGHQSysDate
		, DraftScpComplDate
		, DraftToPRDate
		, DraftToPRSysDate
		--, EDS2_CREATE_DATE
		--, EDSI_CREATE_DATE
		--, EnforcNoticeSentDate
		--, ExitMeeting
		--, ExpCommToPrud31
		--, ExpDatetoPolicyAsstDir
		--, ExpDraftFrPRDate
		--, ExpDraftRegHQ31
		--, ExpDraftRgHQDate
		--, ExpDraftToPRDate
		--, ExpHQApprovalDate
		--, ExpHQCommConsolidation
		--, ExpHQCommConsolidation31
		--, ExpRtnFromAllDate
		--, FMApprovalDate
		--, GPRADeadline
		--, HQApprovalDate
		--, HQApprovalSysDate
		--, InitOffsiteAnalEnd
		--, LegalReviewComp
		, MAIL_DATE
		, MAIL_SYS_DATE
		, OnSiteReviewCompl
		, OnsiteReviewStart
		, PARRNoticeRecDate
		, PARRNoticeSentDate
		, PolEstIssuanceDate
		, RDApprovalDate
		, RegsMemoRecDate
		, RegsMemoSentDate
		, RtnEnfmtDate
		, RtnfromOversightDate
		, RtnfromPolicyDate
		, RtnOFLEODate
		, SchOnSiteStartDate
		, START_DATE
		, START_DUE_DATE
		, StartDueDateCO
		, StartDueDateCRA
		, StartDueDateHC
		, StartDueDateIT
		, StartDueDateSS
		, StartDueDateTR
		, ToBLetterRecDate
from		SQLORD.dbo.EDS_SUMMARY_RPT
where		ExaminationId in (2674,2755)

*/



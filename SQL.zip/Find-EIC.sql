select	x.ExaminationId
	  ,	x.PersonId
	  ,	x.FirstName + ' ' + x.LastName as The_Name
	  ,
from	(	select	e.ExaminationId
			,	p.PersonId
			,	p.LastName
			,	p.FirstName
			,	p.CFPBId as CFPBID_FEDERATIONID
			,	un.UsernameId
			,	un.Username
			,	row_number() over (partition by un.Username order by e.ExaminationId) as RowNumber
		from		Regulatory.dbo.Examination e
		inner join	Core.dbo.Persons p
			on	e.EIC = p.PersonId
		inner join	Core.dbo.UserNames un
			on	p.PersonId = un.PersonId
		where		e.EIC <> 1029	
	)x
	


select	ExaminationId
from		Regulatory.dbo.Examination
where		EIC = 11038
	
	
select	distinct p.PersonId
	  ,	pe.EmailAddress
	  ,	p.CFPBId
from		Regulatory.dbo.Examination e
inner join	Core.dbo.Persons p
	on	e.EIC = p.PersonId
inner join	Core.dbo.PersonEmailAddresses pe
	on	p.PersonId = pe.PersonId	
where		e.EIC <> 1029	
	and	p.CFPBId = 'U2KAAT'
--	and	pe.EmailAddress = 'margaret.lewis@cfpb.gov'
	
		  	
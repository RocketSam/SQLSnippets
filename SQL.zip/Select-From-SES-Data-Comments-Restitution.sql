SELECT
  rad.RADId
, '' as Docket
, '' as ExaminationId
, Replace(rad.RADComments, char(13)+char(10), '. ') as RADComments
,'' as ISSUE_VIOLATION__C
,'Other' as COMMENT_TYPE__C
, rad.CreatedBy
, rad.CreatedDate
, rad.ModifiedBy
, rad.ModifiedDate
,'Restitution' as ObjectType
FROM SQLORD.dbo.RadActionDetail rad
LEFT JOIN SQLORD.dbo.RadRelatedExams rre ON rad.RadId=rre.RadId and rad.Docket=rre.Docket
where RADComments is not null
order by ExaminationId


select	top 10 *
from		SQLORD.dbo.RadActionDetail


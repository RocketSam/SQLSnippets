select	esr.DOCKET
		, esr.ExaminationId
		--, EXAM_TYPE
		--, ARCDecisionDate
		--, ARCMemoFinalDate
		, ARDApprovalDate
		--, CommHQRGDate2
		--, CommHQRGDate3
		--, DatetoAssocDir
		, DatetoExaminations
		--, DatetoExamAsstDir
		--, DatetoOFLEOFinalRev
		--, DatetoOFLEO
		--, DatetoPolicy
		--, DatetoPolicyAsstDir
		--, DraftFrPRDate
		, DraftHQDistribution
		, DraftRGHQDate
		--, DraftRGHQDate2
		--, DraftRGHQDate3
		, RtnEnfmtDate
		, RtnOFLEODate
		--, RtnfromPolicyDate
		--, DraftScpComplDate
		--, DraftToPRDate
		--, PolEstIssuanceDate
		, COMPL_DATE
		--, ExitMeeting
		, ExpRtnFromAllDate
		, FMApprovalDate
		--, HQApprovalDate
		, CommHQRGDate
		, emt.PERKCompleteDate
		, emt.PERKMailDate
		--, InitOffsiteAnalEnd
		--, LegalReviewComp
		, emt.ScheduledComplDate
		, emt.ScheduledStartDate
		, SchOnSiteStartDate
		, SchOnSiteStartDate
		, OnSiteReviewCompl
		, OnsiteReviewStart
		--, PARRNoticeRecDate
		--, PARRNoticeSentDate
		--, ToBLetterRecDate
		--, EnforcNoticeSentDate
		, RDApprovalDate
		--, RegsMemoRecDate
		--, RegsMemoSentDate
		, [START_DATE]
from		SQLORD.dbo.EDS_SUMMARY_RPT esr
left join	SQLORD.dbo.EDS_MISC_RPT emt
	on	esr.ExaminationId = emt.ExaminationId
where	 (	ARCDecisionDate Is Not Null
	or	ARCMemoFinalDate Is Not Null
	or	ARDApprovalDate Is Not Null
	or	CommHQRGDate2 Is Not Null
	or	CommHQRGDate3 Is Not Null
	or	DatetoAssocDir Is Not Null
	or	DatetoExaminations Is Not Null
	or    DatetoExamAsstDir Is Not Null
	or	DatetoOFLEOFinalRev Is Not Null
	or	DatetoOFLEO Is Not Null
	or	DatetoPolicy Is Not Null
	or	DatetoPolicyAsstDir Is Not Null
	or	DraftFrPRDate Is Not Null
	or	DraftHQDistribution Is Not Null
	or	DraftRGHQDate Is Not Null
	or	DraftRGHQDate2 Is Not Null
	or	DraftRGHQDate3 Is Not Null
	or	RtnEnfmtDate Is Not Null
	or	RtnOFLEODate Is Not Null
	or	RtnfromPolicyDate Is Not Null
	or	DraftScpComplDate Is Not Null
	or	DraftToPRDate Is Not Null
	or	PolEstIssuanceDate Is Not Null
	or	COMPL_DATE Is Not Null
	or	ExitMeeting Is Not Null
	or	ExpRtnFromAllDate Is Not Null
	or	FMApprovalDate Is Not Null
	or	HQApprovalDate Is Not Null
	or	CommHQRGDate Is Not Null
	or	emt.PERKCompleteDate Is Not Null
	or	emt.PERKMailDate Is Not Null
	or	InitOffsiteAnalEnd Is Not Null
	or	LegalReviewComp Is Not Null
	or	emt.ScheduledComplDate Is Not Null
	or	emt.ScheduledStartDate Is Not Null
	or	SchOnSiteStartDate Is Not Null
	or	SchOnSiteStartDate Is Not Null
	or	OnSiteReviewCompl Is Not Null
	or	OnsiteReviewStart Is Not Null
	or	PARRNoticeRecDate Is Not Null
	or	PARRNoticeSentDate Is Not Null
	or	ToBLetterRecDate Is Not Null
	or	EnforcNoticeSentDate Is Not Null
	or	RDApprovalDate Is Not Null
	or	RegsMemoRecDate Is Not Null
	or	RegsMemoSentDate Is Not Null
	or	[START_DATE] Is Not Null
	)
	and	esr.ExaminationId = 63
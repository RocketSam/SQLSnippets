/***	DOCKET CHECK  ***/

declare	@charDOCKET	char(5),
		@intDOCKET integer,
		@vcNAME varchar(75),
		@vcEntSts varchar(1),
		@vcFM varchar(75),
		@vcARD varchar(75)
		
select	@charDOCKET = '00253'

select	@charDOCKET =	air.DOCKET
	,	@vcNAME	=	air.[NAME]
	,	@vcEntSts	=	air.ENTITY_STATUS
	,	@intDOCKET	=	CAST(air.DOCKET as integer)
	,	@vcFM		=	cdr.FM_FNAME + ' ' + cdr.FM_LNAME
	,	@vcARD	=	cdr.CM_FNAME + ' ' + cdr.CM_LNAME
from		SQLORD.dbo.ALL_INSTITUTIONS_RPT air
left join	SQLORD.dbo.CASELOAD_DKTS_RPT cdr
	on	air.DOCKET = cdr.DOCKET
where		air.DOCKET = @charDOCKET

print		'Source: SQLORD.dbo.ALL_INSTITUTIONS_RPT'
print		'Docket: ' + @charDOCKET
print		'Name:   ' + @vcNAME
print		'Status: ' + @vcEntSts
print		'Field Manager: ' + @vcFM
print		'Assistant Regional Director: ' + @vcARD
print		'---------------------------------------------------------'

select	@charDOCKET =	o.Docket
	,	@vcNAME	=	sp.[NAME]
	,	@vcEntSts	=	o.OrganizationStatusCode
	,	@intDOCKET	=	CAST(o.Docket as integer)
from		CSM.dbo.Organizations o
left join	CSM.dbo.ServiceProviders sp
	on	o.Docket = sp.Docket
where		o.Docket = @charDOCKET

print		'Source: CSM.dbo.Organizations'
print		'Docket: ' + @charDOCKET
print		'Name:   ' + @vcNAME
print		'Status: ' + @vcEntSts
print		'---------------------------------------------------------'

select	@charDOCKET =	v.Docket
	,	@vcNAME	=	v.[NAME]
	,	@vcEntSts	=	v.Entity_Status
	,	@intDOCKET	=	CAST(v.Docket as integer)
from		SQLORD.dbo.VW_LoadViewAllInstitutionsRptIT v
where		v.Docket = @charDOCKET

print		'Source: SQLORD.dbo.VW_LoadViewAllInstitutionsRptIT'
print		'Docket: ' + @charDOCKET
print		'Name:   ' + @vcNAME
print		'Status: ' + @vcEntSts
print		'---------------------------------------------------------'

/*
use SQLORD
select	TABLE_NAME, COLUMN_NAME
from		INFORMATION_SCHEMA.COLUMNS
where		COLUMN_NAME LIKE '%comment%'
order by	TABLE_NAME, COLUMN_NAME

	select	*
	from		SQLORD.dbo.RadActionDetail
	where		docket = '00259'
	
	select	*
	from		CSM.dbo.ServiceProviderComments spc
	inner join	CSM.dbo.Comments c
		on	spc.CommentId = c.CommentId
	where		c.Comment like '%Embrace Home Loans Inc%'
	

select	o.Docket
	,	c.Comment
from		CSM.dbo.Comments c 
inner join	CSM.dbo.ServiceProviderComments o 
	on	c.CommentId = o.commentId 
where		c.CommentTypeCode='SPC'
	and	o.Docket = '00259'
	
	
	
*/	


	

		
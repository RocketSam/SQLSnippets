SELECT
  'RAD' + cast(vra.RADId as varchar(10)) as RADId
, vra.Docket
, vra.ActionCode
, vra.ActionDescription
, vra.ActionLongDescription
, vra.ActionType
, vra.IsPublicRelease
, vra.IsChiefCounsel
, vra.RegionId
, vra.RegionAbv
, vra.RegionName
, vra.EffectiveDate
, vra.InitiatedDate
, vra.ActionStatus
, vra.CloseCode
, vra.CloseDescription
, vra.CloseDate
, vra.CreatedDate
, vra.ModifiedDate
, vra.ComplianceInd
, vra.ComplianceDate
, vra.Voided
, vra.RADType
, vra.OrderNo
, vra.RADId as originalkey
, vra.AgainstDocket
, rad.Entity2ndResponse
, rad.CFPB2ndFollowup
, rad.EntityResponse
, rad.CFPBFollowup
, Replace(rad.RADComments, char(13)+char(10), '. ') as RADComments
, rad.NotifyIAPDate
, c.ShortDescript --based off query sent by Nancy Murphy
, rre.ExaminationId
,vra.RADID as SES1_ACTION_ID__C
FROM SQLORD.dbo.VW_RADActionsFlat vra 
left join SQLORD.dbo.RADActionDetail rad on vra.RadId=rad.RadId 
left join Regulatory.dbo.RADCodes rc on vra.RadId=rc.RadId
left join Regulatory.dbo.Codes c on rc.CodeId=c.CodeId 
left join Regulatory.dbo.RadRelatedExam rre on vra.RadId=rre.RadId
where c.CodeTypeId=104 and vra.Voided=0 --fix to SFSES-1718
order by 1

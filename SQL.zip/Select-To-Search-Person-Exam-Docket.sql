/*
select	*
from		INFORMATION_SCHEMA.COLUMNS
where		COLUMN_NAME like '%ReasonCode%'
order by	TABLE_NAME, COLUMN_NAME

SELECT	TABLE_NAME 
FROM		INFORMATION_SCHEMA.COLUMNS 
WHERE		COLUMN_NAME = 'PersonId' 
UNION
SELECT	*
FROM		INFORMATION_SCHEMA.COLUMNS 
WHERE		COLUMN_NAME = 'RADId'
ORDER BY	TABLE_NAME

SELECT	TABLE_NAME, COLUMN_NAME
FROM		INFORMATION_SCHEMA.COLUMNS
WHERE		TABLE_NAME IN ('RADAGAINST')
ORDER BY	TABLE_NAME, ORDINAL_POSITION

SELECT	COLUMN_NAME
FROM		INFORMATION_SCHEMA.COLUMNS
WHERE		TABLE_NAME = '

*/

declare	@intPersonId integer,
		@intExamId integer,
		@charDocket char(5)
		
select	@intPersonId = 9908,
		@intExamId = 395,
		@charDocket = '00214'
		
		

select	PrimaryKeyType,
		COUNT(*) as Count_PrimaryKeyType
from		dbo.vw_Followups
where		ReasonDesc = 'UDAAP'
group by	PrimaryKeyType
	
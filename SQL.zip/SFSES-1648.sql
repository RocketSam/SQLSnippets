select	c.ExaminationId
		, c.Docket 
		, c.MAIL_DATE as 'ER Mail Date or Exam Mail Date'
		, c.SchOnSiteStartDate as 'Sched or Scheduled On-site Start'
		, m.ScheduledStartDate as 'ScheduledStartDate from EDS_MISC_RPT'
from		EDS_Summary_RPT c
left join	EDS_MISC_RPT m
	on	c.ExaminationId = m.ExaminationId
where		c.MAIL_DATE <> ''
	and	IsNull(c.SchOnSiteStartDate, '') = ''
	
	
	
SELECT Docket
	,PersonID
	,LastName
	,FirstName
	,MiddleName
	,Prefix
	,Suffix
	,ContactTypeCode
	,ContactTypeDesc
	,Title
	,WorkPhone
	,EmailAddress
	,'Entity Contact' AS RecordType
	,'' AS HireDate
	,'' AS RegionId
	,'' AS LocationState
FROM SQLORD.dbo.InfluentialParties	
where	LastName = 'Hill'

	
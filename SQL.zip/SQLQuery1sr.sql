select	top 10 *
from		dbo.VW_ScheduledEmployees

select	Codes.Code,
		count(ActivitySegments.ActivitySegmentId) as CountActivitySegmentsPerCode
from		dbo.ActivitySegments
inner join	dbo.Codes
	on	ActivitySegments.ActivitySegmentTypeCodeId = Codes.CodeId
group by	Codes.Code
	
select	top 25 *
from		dbo.ActivitySegments
inner join	dbo.Codes
	on	ActivitySegments.ActivitySegmentTypeCodeId = Codes.CodeId


	


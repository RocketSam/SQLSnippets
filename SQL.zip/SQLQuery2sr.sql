/*
** =============================================================================
**   T-SQL Code Name: VW_ScheduledEmployees
**   T-SQL Type:      view
**   Author:          Mary Oechsler
**   Date Modified:   11/07/2005
**   Purpose:         This view provides a list of Scheduled Employee activities.
**                         
** 
**   Modifications History
**   Date        By   Modification
**   ----------  ---  ------------
**   12/06/2006  SYN  Added ContactPhone column per Richard Peralta
**   08/20/2007  THN  Cleaned up view to make it more readable
**   10/19/2007  THN  Added column ActivityID requested by Amir
** =============================================================================

** BEGIN SCRIPT HERE **
USE [Regulatory]
GO

/****** Object:  View [dbo].[VW_ScheduledEmployees]    Script Date: 7/28/2016 9:46:47 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE  VIEW [dbo].[VW_ScheduledEmployees]
AS

*/
SELECT DISTINCT
       'ActivityTypeCode' = Codes.Code,
       'PersonID'         = CASE
                               WHEN CODES.CODE = 'R' THEN ExamAct.PersonId
                               WHEN CODES.Code = 'E' THEN ExamSched.PersonId
                            END,
       'ActivityCode'     = CASE
                               WHEN ExamSched.ExaminationId > 0 THEN 'E'
                               ELSE CODE1.Code
                            END,
       'ActivityCodeDescription' 
                          = CASE
                               WHEN ExamSched.ExaminationId > 0 THEN 'Exam'
                               ELSE CODE1.ShortDescript
                            END,
       'Comment'          = CASE
                               WHEN Codes.Code = 'E' THEN ExamSched.Comment
                               WHEN Codes.Code = 'R' THEN ExamAct.Comment
                            END,
       'ExaminationID'    = ExamSched.ExaminationId,
       'ContactPhone'     = CASE
                               WHEN Codes.Code = 'E' THEN ExamSched.ContactPhone
                               WHEN Codes.Code = 'R' THEN ExamAct.ContactPhone
                            END,
       'EstimatedDays'    = CASE
                               WHEN Codes.Code = 'E' THEN ExamSched.EstimatedDays
                               WHEN Codes.Code = 'R' THEN ExamAct.EstimatedDays
                            END,   
       'SchedActivityStartDate' = ActSeg.StartDate, 
       'SchedActivityEndDate'   = ActSeg.EndDate,
       'ActivityID'             = ActSeg.ActivityID
  FROM dbo.ActivitySegments ActSeg
       JOIN dbo.Codes
         ON ActSeg.ActivitySegmentTypeCodeId = Codes.CodeId
       JOIN dbo.CodeTypes CT
         ON CT.Code = 'ACTSEG'
       LEFT JOIN dbo.ExaminerActivities ExamAct 
         ON ActSeg.ActivityId = examAct.ExaminerActivityId 
        AND Codes.Code = 'R'
       LEFT JOIN dbo.Codes CODE1    
         ON examAct.ExaminerActivityCodeId = CODE1.CodeId
       LEFT JOIN dbo.ExamSchedule ExamSched
         ON ActSeg.ActivityId = ExamSched.ExamScheduleId 
        AND Codes.Code = 'E'
   




GO

select	Docket, [Name], Entity_Status
from		SQLORD.dbo.ALL_INSTITUTIONS_RPT
where		entity_status = 'A'


select	count(*)
from		CSM.dbo.Organizations
where		OrganizationStatusCode = 'A'

select	Entity_Status,
		count(Distinct Docket) as Count_Docket
from		SQLORD.dbo.ALL_INSTITUTIONS_RPT
group by	Entity_Status
with rollup


select	Docket
		, ModifiedDate
		, OrganizationStatusCode
		, [Name]
		, Entity_Region
from		CSM.dbo.Organizations
where		Docket in ('00019','00020','00068','00262','00337','00543')



select	Docket
		, Entity_Status
		, Region_Name
from		SQLORD.dbo.ALL_INSTITUTIONS_RPT
where		Docket in ('00019','00020','00068','00262','00337','00543')

select	*
from		CSM.dbo.Organizations
where		Docket in ('00019','00011')

select	Docket, CITY, STATE, COUNTRY
from		SQLORD.dbo.ALL_INSTITUTIONS_RPT
where		Docket in ('00011','00018','00019','00020','00068','00262','00337','00543')	








-- SES1 Account/Entity Data from ALL_INSTITUTIONS_RPT (AIR)

select	DOCKET
		, MlsID as [NMLS_ID]
		, ENTITY_TYPE
		, Entity_Type_Desc
		, ENTITY_STATUS
		, [NAME]
		, [ADDRESS]
		, [CITY]
		, [STATE]
		, ZIP
		, COUNTRY
		, MailAddress
		, REGION_NAME
		, RSSDId
		, TaxId
from		dbo.ALL_INSTITUTIONS_RPT

/*
sp_who

select	COUNT(*) as count_codes
from		Codes

select	COUNT(*) as count_Documents
from		Documents
where		DocCategoryCodeId = 893
	and	ApplicationSystemId = 33
	and	Unzip = 0	
*/
-- this one is good for selecting from Documents
select	r.RelatedId,
		d.DocumentId,
		DATALENGTH(d.Document) as Doc_Data_Length_In_Bytes,
		d.FileSize,
		--MAX(d.FileSize) as Max_File_Size_In_Kilobytes
		--MAX(DATALENGTH(d.Document)) as Max_Data_Length_In_Bytes\
		d.CreatedDate,
		d.ModifiedDate
from		Documents d
inner join	DocumentsRes r
	on	d.DocumentId = r.DocumentId
where		r.RelatedId in
	(	select	ExaminationId
		from		Examination 
		where		Docket in
		(	select Docket
			from   VW_Institutions
			where	 SupervisoryRegion = 1
		)	
		and		DeletedDate is null
		--and		ExaminationId between 1 and 499
		--and		ExaminationId <= 592
	)	
	and	d.ApplicationSystemId = 33  --Examinations
	and	d.Unzip = 0
	and	d.DocCategoryCodeId = 893 --'CFPB Final Exam Report'
	--and	d.FileSize > 65000  --greater than 64 MB (approx)
	and   DATALENGTH(d.Document) > 10006524
ORDER BY	Doc_Data_Length_In_Bytes desc	
--18006524
/*

-- this one is good for selecting exams 
select	COUNT(DISTINCT r.RelatedId) as count_examinations
--select	COUNT(r.RelatedId) as count_exams
--select	COUNT(r.DocumentId) as count_docs
select	r.DocumentId,
		r.RelatedId as ExaminationId,
		e.Docket
from		DocumentsRes r
inner join	Examination e
	on	e.ExaminationId = r.RelatedId
where		r.DocumentId in
	(	select	DocumentId
		from		Documents
		where		DocCategoryCodeId = 893
			and	ApplicationSystemId = 33
			and	Unzip = 0
	)
	and	e.DeletedDate is null
	and	e.Docket in
	(	select	Docket
		from		VW_Institutions
		where		SupervisoryRegion = 1
	)		
	and	e.ExaminationId = 592
	
	
select	COUNT(*) as count_Documents_33
from		Documents d
left join	Codes c
	on	d.DocCategoryCodeId = c.CodeId
where		d.ApplicationSystemId = 33
	and	d.Unzip = 0
	and	c.ShortDescript = 'CFPB Final Exam Report'
	
	
select	*
from		Codes
where		ShortDescript = 'CFPB Final Exam Report'

	

select	COUNT(*) as count_DocumentsRes
from		DocumentsRes

select	COUNT(*) as count_Examination
from		Examination

select	MAX(ExaminationId) as MaxId,
		MIN(ExaminationId) as MinId
from		Examination
		

select	*
from		Examination
where		DeletedDate is null

select	COUNT(*) as count_VW_Institutions
from		VW_Institutions

select	*
from		VW_Institutions
where		SupervisoryRegion = 1


*/
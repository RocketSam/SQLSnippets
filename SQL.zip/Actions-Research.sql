/***		ACTIONS RESEARCH		***/

/***		VARIABLE DECLARATION	***/
declare	@intExaminationId	integer,
		@intRADId		integer,
		@intFollowUpID	integer,
		@varcharDocket	varchar(5)			
		
/***		VARIABLE INITIALIZATION	***/		
select	@intExaminationId = 120
select	@varcharDocket = '00105'
select	@intRADId = 0
select	@intFollowUpID = 1308

/***		DATABASES and TABLES INVOLVED

		SQLORD.dbo.vw_Followups with ReasonTypeCode of "MRA" --> MRA Actions
		SQLORD.dbo.vw_Followups with ReasonTypeCode of "Non-MRA" --> Issues
		SQLORD.dbo.vw_RADActionsFlat --> MOU Actions

***/

		
select	'MRAs', *
from		SQLORD.dbo.vw_Followups
where		PrimaryKeyType = 'ExaminationID'
	and	ReasonTypeCode = 'MRA'
	--and	FollowUpID = @intFollowUpID
	
select	COUNT(*) as CountMRAs
from		SQLORD.dbo.vw_Followups
where		ReasonTypeCode = 'MRA'
	and	PrimaryKeyType = 'ExaminationID'
	
select	COUNT(DISTINCT PrimaryKey) as CountExams
from		SQLORD.dbo.vw_Followups
where		ReasonTypeCode = 'MRA'
	and	PrimaryKeyType = 'ExaminationID'	
	

select	COUNT(PrimaryKey)
from	(
select	PrimaryKey,
		COUNT(*) as CountMRAsPerExam
from		SQLORD.dbo.vw_Followups
where		ReasonTypeCode = 'MRA'
	and	PrimaryKeyType = 'ExaminationID'	
group by	PrimaryKey
)x
where		CountMRAsPerExam between 21 and 50


select	AVG(CountMRAsPerExam)
from	(
select	PrimaryKey,
		COUNT(*) as CountMRAsPerExam
from		SQLORD.dbo.vw_Followups
where		ReasonTypeCode = 'MRA'
	and	PrimaryKeyType = 'ExaminationID'	
group by	PrimaryKey
)x
--where		CountMRAsPerExam between 1 and 5
group by	PrimaryKey

	
select	*
from		SQLORD.dbo.VW_RADActionsFlat	
where		Docket = @varcharDocket

select	ActionCode,
		ActionDescription,	
		COUNT(*)
from		SQLORD.dbo.VW_RADActionsFlat
group by	ActionCode,
		ActionDescription


select	PrimaryKeyType,
		ReasonTypeCodeDesc,
		COUNT(*) as ReasonTypeCodeCount
from		SQLORD.dbo.vw_Followups
group by	ReasonTypeCodeDesc,
		PrimaryKeyType
		

select	*
from		SQLORD.dbo.vw_Followups
where		ReasonTypeCodeDesc = 'NonMRA'

select	COUNT(distinct Docket) as countDockets
from		SQLORD.dbo.VW_RADActionsFlat
where		ActionCode = 'S12B'

select	*
from		SQLORD.dbo.RadActionDetail


select	COUNT(distinct RADID) as CountRAD
from		SQLORD.dbo.RADActionDetail
where		ActionCode = 'S12B'



	
